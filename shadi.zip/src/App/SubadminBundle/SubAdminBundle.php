<?php

namespace App\SubadminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SubAdminBundle extends Bundle
{
}
