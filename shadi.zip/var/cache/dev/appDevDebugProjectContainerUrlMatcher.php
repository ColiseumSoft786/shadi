<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/Subadmin/log')) {
            // sub_admins_login
            if ($pathinfo === '/Subadmin/login') {
                return array (  '_controller' => 'App\\SubadminBundle\\Controller\\DefaultController::loginAction',  '_route' => 'sub_admins_login',);
            }

            // sub_admins_logout
            if ($pathinfo === '/Subadmin/logout') {
                return array (  '_controller' => 'App\\SubadminBundle\\Controller\\DefaultController::SubAdminLogOutAction',  '_route' => 'sub_admins_logout',);
            }

        }

        if (0 === strpos($pathinfo, '/User')) {
            // sub_admins_users_interest
            if (0 === strpos($pathinfo, '/User/Interest') && preg_match('#^/User/Interest/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sub_admins_users_interest')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\InterestController::InterestAction',));
            }

            // users_notification
            if (0 === strpos($pathinfo, '/User/Notification') && preg_match('#^/User/Notification/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_notification')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\InterestController::NotificationAction',));
            }

            if (0 === strpos($pathinfo, '/User/Interest')) {
                // users_interest_accept
                if (0 === strpos($pathinfo, '/User/Interest/Accept') && preg_match('#^/User/Interest/Accept/(?P<id>[^/]++)/(?P<action>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'users_interest_accept')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\InterestController::AcceptRejectInterestAction',));
                }

                // single_users_interest_profile
                if (0 === strpos($pathinfo, '/User/Interest/Profile') && preg_match('#^/User/Interest/Profile/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'single_users_interest_profile')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\InterestController::SingleUserProfileInterestAction',));
                }

            }

        }

        // sub_admins_users
        if ($pathinfo === '/SubAdmin/Workplace') {
            return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::UsersAction',  '_route' => 'sub_admins_users',);
        }

        if (0 === strpos($pathinfo, '/User/Profile')) {
            // sub_admins_users_profile
            if (preg_match('#^/User/Profile/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sub_admins_users_profile')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::UserProfileAction',));
            }

            // sub_admins_users_profile_for_others
            if (0 === strpos($pathinfo, '/User/Profile/For/Others') && preg_match('#^/User/Profile/For/Others/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sub_admins_users_profile_for_others')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::UserProfileOthersAction',));
            }

        }

        if (0 === strpos($pathinfo, '/SubAdmin')) {
            // sub_admins_all_members
            if ($pathinfo === '/SubAdmin/All/Members') {
                return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::SubAdminAllMembersAction',  '_route' => 'sub_admins_all_members',);
            }

            // sub_admins_other_members
            if ($pathinfo === '/SubAdmin/Other/Members') {
                return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::SubAdminOtherMembersAction',  '_route' => 'sub_admins_other_members',);
            }

            // sub_admins_my_members
            if ($pathinfo === '/SubAdmin/My/Members') {
                return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::SubAdminMyMembersAction',  '_route' => 'sub_admins_my_members',);
            }

        }

        if (0 === strpos($pathinfo, '/User')) {
            // subadmins_users_insert
            if ($pathinfo === '/User/Insert') {
                return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::UserInsertAction',  '_route' => 'subadmins_users_insert',);
            }

            // sub_admins_users_castes
            if ($pathinfo === '/User/Castes') {
                return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::CastesAction',  '_route' => 'sub_admins_users_castes',);
            }

            if (0 === strpos($pathinfo, '/User/R')) {
                // subadmins_users_rstate
                if ($pathinfo === '/User/RState') {
                    return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::RStateAction',  '_route' => 'subadmins_users_rstate',);
                }

                // subadmins_users_rcity
                if ($pathinfo === '/User/RCity') {
                    return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::RCityAction',  '_route' => 'subadmins_users_rcity',);
                }

            }

        }

        // users_lp_states
        if ($pathinfo === '/Sidebar/LP_State') {
            return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::LPStateAction',  '_route' => 'users_lp_states',);
        }

        if (0 === strpos($pathinfo, '/User')) {
            if (0 === strpos($pathinfo, '/User/LP')) {
                // subadmins_users_lpcity
                if ($pathinfo === '/User/LPCity') {
                    return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::LPCityAction',  '_route' => 'subadmins_users_lpcity',);
                }

                // subadmins_users_lpcastes
                if ($pathinfo === '/User/LP/Castes') {
                    return array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::LPCastesAction',  '_route' => 'subadmins_users_lpcastes',);
                }

            }

            // sub_admins_users_update
            if (0 === strpos($pathinfo, '/User/Update') && preg_match('#^/User/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sub_admins_users_update')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::UserUpdateAction',));
            }

            // sub_admin_user_block
            if (0 === strpos($pathinfo, '/User/Block') && preg_match('#^/User/Block/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sub_admin_user_block')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::BlockUserAction',));
            }

            // sub_admin_user_block_users
            if (0 === strpos($pathinfo, '/Users/Blocks') && preg_match('#^/Users/Blocks/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sub_admin_user_block_users')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::UserBlockAction',));
            }

            // sub_admin_user_delete
            if (0 === strpos($pathinfo, '/User/Delete') && preg_match('#^/User/Delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'sub_admin_user_delete')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::DeleteUserAction',));
            }

        }

        // main_sub_admin_user_delete
        if (0 === strpos($pathinfo, '/Main/User/Delete') && preg_match('#^/Main/User/Delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'main_sub_admin_user_delete')), array (  '_controller' => 'App\\SubadminBundle\\Controller\\UsersController::DeleteUsersAction',));
        }

        if (0 === strpos($pathinfo, '/C')) {
            if (0 === strpos($pathinfo, '/Caste')) {
                // admin_castes
                if ($pathinfo === '/Caste') {
                    return array (  '_controller' => 'App\\AdminBundle\\Controller\\CasteController::CastesAction',  '_route' => 'admin_castes',);
                }

                // admin_caste_insert
                if ($pathinfo === '/Caste/Insert/New') {
                    return array (  '_controller' => 'App\\AdminBundle\\Controller\\CasteController::AddCasteAction',  '_route' => 'admin_caste_insert',);
                }

                // admin_caste_update
                if (0 === strpos($pathinfo, '/Caste/Update') && preg_match('#^/Caste/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_caste_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\CasteController::UpdateCasteAction',));
                }

            }

            if (0 === strpos($pathinfo, '/Cit')) {
                // admin_cities
                if ($pathinfo === '/Cities') {
                    return array (  '_controller' => 'App\\AdminBundle\\Controller\\CityController::CitiesAction',  '_route' => 'admin_cities',);
                }

                if (0 === strpos($pathinfo, '/City')) {
                    // admin_city_insert
                    if ($pathinfo === '/City/Insert/New') {
                        return array (  '_controller' => 'App\\AdminBundle\\Controller\\CityController::AddCityAction',  '_route' => 'admin_city_insert',);
                    }

                    // admin_city_update
                    if (0 === strpos($pathinfo, '/City/Update') && preg_match('#^/City/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_city_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\CityController::UpdateCityAction',));
                    }

                }

            }

            if (0 === strpos($pathinfo, '/Countr')) {
                // admin_countries
                if ($pathinfo === '/Countries') {
                    return array (  '_controller' => 'App\\AdminBundle\\Controller\\CountryController::CountriesAction',  '_route' => 'admin_countries',);
                }

                if (0 === strpos($pathinfo, '/Country')) {
                    // admin_countries_insert
                    if ($pathinfo === '/Country/Insert') {
                        return array (  '_controller' => 'App\\AdminBundle\\Controller\\CountryController::AddCountryAction',  '_route' => 'admin_countries_insert',);
                    }

                    // admin_country_update
                    if (0 === strpos($pathinfo, '/Country/Update') && preg_match('#^/Country/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_country_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\CountryController::UpdateCountryAction',));
                    }

                    // admin_country_delete
                    if (0 === strpos($pathinfo, '/Country/Delete') && preg_match('#^/Country/Delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_country_delete')), array (  '_controller' => 'App\\AdminBundle\\Controller\\CountryController::DeleteCountryAction',));
                    }

                }

            }

        }

        // admin_index
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'admin_index');
            }

            return array (  '_controller' => 'App\\AdminBundle\\Controller\\DefaultController::indexAction',  '_route' => 'admin_index',);
        }

        // workplace_login
        if ($pathinfo === '/WorkPlace/Login') {
            return array (  '_controller' => 'App\\AdminBundle\\Controller\\DefaultController::loginAction',  '_route' => 'workplace_login',);
        }

        // admins_logout
        if ($pathinfo === '/admin/logout') {
            return array (  '_controller' => 'App\\AdminBundle\\Controller\\DefaultController::AdminLogOutAction',  '_route' => 'admins_logout',);
        }

        if (0 === strpos($pathinfo, '/Education')) {
            // admin_education
            if ($pathinfo === '/Education') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\EducationController::EducationsAction',  '_route' => 'admin_education',);
            }

            // admin_education_insert
            if ($pathinfo === '/Education/Insert') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\EducationController::AddEducationAction',  '_route' => 'admin_education_insert',);
            }

            // admin_education_update
            if (0 === strpos($pathinfo, '/Education/Update') && preg_match('#^/Education/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_education_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\EducationController::UpdateEducationAction',));
            }

        }

        // admin_user_membership
        if (0 === strpos($pathinfo, '/User/Membership') && preg_match('#^/User/Membership/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_user_membership')), array (  '_controller' => 'App\\AdminBundle\\Controller\\MembershipController::MembershipAction',));
        }

        // admin_subscribe_membership
        if (0 === strpos($pathinfo, '/Subscribe/Membership') && preg_match('#^/Subscribe/Membership/(?P<userid>[^/]++)/(?P<pkgid>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_subscribe_membership')), array (  '_controller' => 'App\\AdminBundle\\Controller\\MembershipController::SubscribeAction',));
        }

        if (0 === strpos($pathinfo, '/Ocupation')) {
            // admin_ocupations
            if ($pathinfo === '/Ocupation') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\OcupationController::OcupationsAction',  '_route' => 'admin_ocupations',);
            }

            // admin_ocupation_insert
            if ($pathinfo === '/Ocupation/Insert') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\OcupationController::AddOcupationAction',  '_route' => 'admin_ocupation_insert',);
            }

            // admin_ocupation_update
            if (0 === strpos($pathinfo, '/Ocupation/Update') && preg_match('#^/Ocupation/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_ocupation_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\OcupationController::UpdateOcupationAction',));
            }

        }

        if (0 === strpos($pathinfo, '/Package')) {
            // admin_packages
            if ($pathinfo === '/Packages') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\PackagesController::PackagesAction',  '_route' => 'admin_packages',);
            }

            // admin_package_insert
            if ($pathinfo === '/Package/Insert/New') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\PackagesController::AddPackagesAction',  '_route' => 'admin_package_insert',);
            }

            // admin_packages_update
            if (0 === strpos($pathinfo, '/Package/Update') && preg_match('#^/Package/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_packages_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\PackagesController::UpdatePackagesAction',));
            }

            // admin_packages_delete
            if (0 === strpos($pathinfo, '/Package/Del') && preg_match('#^/Package/Del/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_packages_delete')), array (  '_controller' => 'App\\AdminBundle\\Controller\\PackagesController::DeletePackagesAction',));
            }

        }

        if (0 === strpos($pathinfo, '/Religion')) {
            // admin_religions
            if ($pathinfo === '/Religion') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\ReligionController::ReligionAction',  '_route' => 'admin_religions',);
            }

            // admin_religion_insert
            if ($pathinfo === '/Religion/Insert') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\ReligionController::AddReligionAction',  '_route' => 'admin_religion_insert',);
            }

            // admin_religion_update
            if (0 === strpos($pathinfo, '/Religion/Update') && preg_match('#^/Religion/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_religion_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\ReligionController::UpdateReligionAction',));
            }

        }

        // Admin_sub_admins_users_update
        if (0 === strpos($pathinfo, '/Admin/User/Update') && preg_match('#^/Admin/User/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'Admin_sub_admins_users_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::AdminUserUpdateAction',));
        }

        // sub_admin_user_profile_approve
        if (0 === strpos($pathinfo, '/User/Profile/Aprove') && preg_match('#^/User/Profile/Aprove/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'sub_admin_user_profile_approve')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::ProfileApproveAction',));
        }

        if (0 === strpos($pathinfo, '/A')) {
            if (0 === strpos($pathinfo, '/Admin/User')) {
                // admin_sub_admin_user_block
                if (0 === strpos($pathinfo, '/Admin/User/Block') && preg_match('#^/Admin/User/Block/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_sub_admin_user_block')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::AdminBlockUserAction',));
                }

                // admin_sub_admin_user_delete
                if (0 === strpos($pathinfo, '/Admin/User/Delete') && preg_match('#^/Admin/User/Delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_sub_admin_user_delete')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::AdminDeleteUserAction',));
                }

            }

            // all_members
            if ($pathinfo === '/All/Members') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::AllMembersAction',  '_route' => 'all_members',);
            }

        }

        // subadmin_members
        if ($pathinfo === '/SubAdmin/Members') {
            return array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::SubAdminMembersAction',  '_route' => 'subadmin_members',);
        }

        // without_subadmin_members
        if ($pathinfo === '/Without/SubAdmin/Members') {
            return array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::WithoutSubAdminMembersAction',  '_route' => 'without_subadmin_members',);
        }

        if (0 === strpos($pathinfo, '/Admin')) {
            // admins_single_users_profile
            if (0 === strpos($pathinfo, '/Admin/Single/User/Profile') && preg_match('#^/Admin/Single/User/Profile/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admins_single_users_profile')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::UserProfileAction',));
            }

            // admin_user_package_partial
            if (0 === strpos($pathinfo, '/Admin/User/Package/Partial') && preg_match('#^/Admin/User/Package/Partial/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_user_package_partial')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SidebarController::AdminUserPackagePartialViewAction',));
            }

        }

        if (0 === strpos($pathinfo, '/S')) {
            if (0 === strpos($pathinfo, '/State')) {
                // admin_states
                if ($pathinfo === '/States') {
                    return array (  '_controller' => 'App\\AdminBundle\\Controller\\StateController::StateAction',  '_route' => 'admin_states',);
                }

                // admin_state_insert
                if ($pathinfo === '/State/Insert/New') {
                    return array (  '_controller' => 'App\\AdminBundle\\Controller\\StateController::AddStateAction',  '_route' => 'admin_state_insert',);
                }

                // admin_state_update
                if (0 === strpos($pathinfo, '/State/Update') && preg_match('#^/State/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_state_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\StateController::UpdateStateAction',));
                }

            }

            if (0 === strpos($pathinfo, '/SubAdmin')) {
                // admin_subadmins
                if ($pathinfo === '/SubAdmins') {
                    return array (  '_controller' => 'App\\AdminBundle\\Controller\\SubadminController::SubAdminAction',  '_route' => 'admin_subadmins',);
                }

                // admin_subadmin_insert
                if ($pathinfo === '/SubAdmin/Insert') {
                    return array (  '_controller' => 'App\\AdminBundle\\Controller\\SubadminController::AddSubAdminAction',  '_route' => 'admin_subadmin_insert',);
                }

                // admin_subadmin_update
                if (0 === strpos($pathinfo, '/SubAdmin/Update') && preg_match('#^/SubAdmin/Update/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_subadmin_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SubadminController::UpdateSubAdminAction',));
                }

                // admin_subadmin_delete
                if (0 === strpos($pathinfo, '/SubAdmin/Delete') && preg_match('#^/SubAdmin/Delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_subadmin_delete')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SubadminController::DeleteSubAdminAction',));
                }

                // admin_subadmin_block
                if (0 === strpos($pathinfo, '/SubAdmin/Block') && preg_match('#^/SubAdmin/Block/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_subadmin_block')), array (  '_controller' => 'App\\AdminBundle\\Controller\\SubadminController::BlockSubAdminAction',));
                }

            }

        }

        // home_homepage
        if ($pathinfo === '/af') {
            return array (  '_controller' => 'App\\HomeBundle\\Controller\\DefaultController::indexAction',  '_route' => 'home_homepage',);
        }

        // homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
