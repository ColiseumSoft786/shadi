<?php

/* AdminBundle:Admin/Country:country.html.twig */
class __TwigTemplate_c786b9ce4045c587631b87bf91a197ec2aac0eb11c93b3b367967a37245666e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Admin/Country:country.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_44a7636f9a2fddc6ed1000c1fdf1525c7751fb8815c6f6b2a6b81058df3a8151 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44a7636f9a2fddc6ed1000c1fdf1525c7751fb8815c6f6b2a6b81058df3a8151->enter($__internal_44a7636f9a2fddc6ed1000c1fdf1525c7751fb8815c6f6b2a6b81058df3a8151_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Country:country.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_44a7636f9a2fddc6ed1000c1fdf1525c7751fb8815c6f6b2a6b81058df3a8151->leave($__internal_44a7636f9a2fddc6ed1000c1fdf1525c7751fb8815c6f6b2a6b81058df3a8151_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_920878c32de5310f2853c80593d6f0246e7cea7d218fc8ed362b8087c9c00bd2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_920878c32de5310f2853c80593d6f0246e7cea7d218fc8ed362b8087c9c00bd2->enter($__internal_920878c32de5310f2853c80593d6f0246e7cea7d218fc8ed362b8087c9c00bd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>

    <h4 style=\"padding: 10px 0px;\">Countries</h4> <span><a href=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_countries_insert");
        echo "\" class=\"btn btn-info\">Add Country</a></span>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Countries</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Countries"] ?? $this->getContext($context, "Countries")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 43
            echo "            <tr class=\"odd gradeX\">
                <td> &nbsp; ";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"";
            // line 46
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_country_update", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                    ";
            // line 48
            echo "                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>Countries</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_920878c32de5310f2853c80593d6f0246e7cea7d218fc8ed362b8087c9c00bd2->leave($__internal_920878c32de5310f2853c80593d6f0246e7cea7d218fc8ed362b8087c9c00bd2_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Country:country.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 51,  99 => 48,  95 => 46,  90 => 44,  87 => 43,  83 => 42,  70 => 32,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::admin.html.twig' %}

{% block body %}
    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>

    <h4 style=\"padding: 10px 0px;\">Countries</h4> <span><a href=\"{{ path('admin_countries_insert') }}\" class=\"btn btn-info\">Add Country</a></span>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Countries</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        {% for item in Countries %}
            <tr class=\"odd gradeX\">
                <td> &nbsp; {{ item.name }}</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"{{ path('admin_country_update',{id:item.id}) }}\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                    {#<a href=\"{{ path('admin_country_delete',{id:item.id}) }}\" class=\"btn btn-danger btn-sm btn-icon icon-left\"> <i class=\"entypo-cancel\"></i>Delete</a>#}
                </td>
            </tr>
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>Countries</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "AdminBundle:Admin/Country:country.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Country/country.html.twig");
    }
}
