<?php

/* AdminBundle:Default:index.html.twig */
class __TwigTemplate_603a28f4e7cdff6e0fb5d175b548f37e9c171ec41445d2b49fd93be8416e0f04 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin.html.twig", "AdminBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0776f9b7e0a97a3e946d137b01a4ca00e2c44717a5e76b8b6a9065f4df6b4661 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0776f9b7e0a97a3e946d137b01a4ca00e2c44717a5e76b8b6a9065f4df6b4661->enter($__internal_0776f9b7e0a97a3e946d137b01a4ca00e2c44717a5e76b8b6a9065f4df6b4661_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0776f9b7e0a97a3e946d137b01a4ca00e2c44717a5e76b8b6a9065f4df6b4661->leave($__internal_0776f9b7e0a97a3e946d137b01a4ca00e2c44717a5e76b8b6a9065f4df6b4661_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_81accd9ea2e613777973ad074153a150f42ee3ffc63d9512240b90380815cea3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81accd9ea2e613777973ad074153a150f42ee3ffc63d9512240b90380815cea3->enter($__internal_81accd9ea2e613777973ad074153a150f42ee3ffc63d9512240b90380815cea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"col-md-12\" style=\"text-align: center; padding: 150px 0px 250px 0px;\">
        <h1 style=\" margin: 0 auto;\">Welcome To Dashboard!</h1>
    </div>
";
        
        $__internal_81accd9ea2e613777973ad074153a150f42ee3ffc63d9512240b90380815cea3->leave($__internal_81accd9ea2e613777973ad074153a150f42ee3ffc63d9512240b90380815cea3_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin.html.twig' %}

{% block body %}
    <div class=\"col-md-12\" style=\"text-align: center; padding: 150px 0px 250px 0px;\">
        <h1 style=\" margin: 0 auto;\">Welcome To Dashboard!</h1>
    </div>
{% endblock %}", "AdminBundle:Default:index.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Default/index.html.twig");
    }
}
