<?php

/* SubAdminBundle:Users:Profileothers.html.twig */
class __TwigTemplate_fffbeda8f24c4cdded2799e26e11775cda73668c09370f5e37054a2fe0fc8a03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::subadmin.html.twig", "SubAdminBundle:Users:Profileothers.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::subadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6c1a4fc547e50b5e8158a0f9e2a90ba6157099449676cb24b674102140601a89 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c1a4fc547e50b5e8158a0f9e2a90ba6157099449676cb24b674102140601a89->enter($__internal_6c1a4fc547e50b5e8158a0f9e2a90ba6157099449676cb24b674102140601a89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SubAdminBundle:Users:Profileothers.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6c1a4fc547e50b5e8158a0f9e2a90ba6157099449676cb24b674102140601a89->leave($__internal_6c1a4fc547e50b5e8158a0f9e2a90ba6157099449676cb24b674102140601a89_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a3de349cfbacbc237ffa1d501c6227556bc418f871f19f703c3da1a92de6def0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a3de349cfbacbc237ffa1d501c6227556bc418f871f19f703c3da1a92de6def0->enter($__internal_a3de349cfbacbc237ffa1d501c6227556bc418f871f19f703c3da1a92de6def0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <h2>User Profile</h2> <br/>
    <div class=\"row\">
        <div class=\"col-md-12\">
            <div class=\"panel panel-primary\" data-collapsed=\"0\">
                <div class=\"panel-heading\">
                    <div class=\"panel-title\">
                        Profile
                    </div>
                    <div class=\"panel-options\"> <a href=\"#\" data-rel=\"collapse\"><i
                                    class=\"entypo-down-open\"></i></a> <a href=\"#\" data-rel=\"reload\"><i
                                    class=\"entypo-arrows-ccw\"></i></a> <a href=\"#\" data-rel=\"close\"><i
                                    class=\"entypo-cancel\"></i></a></div>
                </div>
                <div class=\"panel-body\">
                    <form action=\"\" method=\"post\" enctype=\"multipart/form-data\" role=\"form\" class=\"form-horizontal form-groups-bordered\">


                        <div class=\"form-group\">
                            <div class=\"col-sm-3\">
                                ";
        // line 24
        if (($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "approve", array()) == 1)) {
            // line 25
            echo "                                    ";
            if (($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "privacy", array()) == 1)) {
                // line 26
                echo "                                        <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/assets/icon.png"), "html", null, true);
                echo "\" style=\"width: 100px; height: 100px;\" alt=\"\">
                                    ";
            } else {
                // line 28
                echo "                                        <img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Upic", array())), "html", null, true);
                echo "\" style=\"width: 100%;\" alt=\"\">
                                    ";
            }
            // line 30
            echo "                                ";
        }
        // line 31
        echo "                            </div>
                            <div class=\"col-sm-9\">
                                ";
        // line 34
        echo "                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Uname", array()), "html", null, true);
        echo "\" readonly class=\"form-control\">
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" readonly value=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Uphone", array()), "html", null, true);
        echo "\" class=\"form-control\">
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"password\" value=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "password", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Ugender", array()), "html", null, true);
        echo "\" class=\"form-control\" readonly>
                            </div>
                            <div class=\"col-sm-4\">
                                    <input type=\"text\" value=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "UMartialStatus", array()), "html", null, true);
        echo "\" class=\"form-control\" readonly>
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Color", array()), "html", null, true);
        echo "\" class=\"form-control\" readonly>
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 63
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Uage", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Uheight", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Education", array()), "name", array()), "html", null, true);
        echo "\" class=\"form-control\" readonly>
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Ujobbusinesstitle", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Ujobbusiness", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Ocupation", array()), "name", array()), "html", null, true);
        echo "\" class=\"form-control\" readonly>
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 87
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Uincome", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 90
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Religion", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Caste", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 99
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "UBodyType", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 102
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "URide", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Bearhijab", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <h3>Family details</h3>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 113
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Ufatherocupation", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 116
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Umotherocupation", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 119
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Umothertongue", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-3\">
                                <input type=\"text\" value=\"";
        // line 125
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Ubrothers", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-3\">
                                <input type=\"text\" value=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Usisters", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-3\">
                                <input type=\"text\" value=\"";
        // line 131
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Umarriedbrothers", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-3\">
                                <input type=\"text\" value=\"";
        // line 134
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Umarriedsisters", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>


                        <h3>Residence</h3>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "UAccommodation", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 146
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "UAccommodationStatus", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 149
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Uhousesize", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 155
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Country", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 158
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "State", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 161
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "City", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>


                        <h3>Life partner Requirements</h3>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 170
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpminage", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 173
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpmaxage", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 176
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpheight", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 182
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpcountry", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 185
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpstate", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 188
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpcity", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 194
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpreligion", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"";
        // line 197
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpcaste", array()), "name", array()), "html", null, true);
        echo "\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <textarea class=\"form-control\" readonly>";
        // line 200
        echo twig_escape_filter($this->env, $this->getAttribute(($context["Users"] ?? $this->getContext($context, "Users")), "Lpmessage", array()), "html", null, true);
        echo "</textarea>
                            </div>
                        </div>
                        ";
        // line 208
        echo "                    </form>
                </div>
            </div>
        </div>
    </div>
    <br><br><br><br><br>
    <br><br><br><br><br>

    <script>
        \$(document).ready(function () {
            \$(\"#caste\").prop( \"disabled\", true );
            \$(\"#rstate\").prop( \"disabled\", true );
            \$(\"#rcity\").prop( \"disabled\", true );
            \$(\"#lpstate\").prop( \"disabled\", true );
            \$(\"#lpcity\").prop( \"disabled\", true );
            \$(\"#lpcaste\").prop( \"disabled\", true );
        });

    </script>
";
        
        $__internal_a3de349cfbacbc237ffa1d501c6227556bc418f871f19f703c3da1a92de6def0->leave($__internal_a3de349cfbacbc237ffa1d501c6227556bc418f871f19f703c3da1a92de6def0_prof);

    }

    public function getTemplateName()
    {
        return "SubAdminBundle:Users:Profileothers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  377 => 208,  371 => 200,  365 => 197,  359 => 194,  350 => 188,  344 => 185,  338 => 182,  329 => 176,  323 => 173,  317 => 170,  305 => 161,  299 => 158,  293 => 155,  284 => 149,  278 => 146,  272 => 143,  260 => 134,  254 => 131,  248 => 128,  242 => 125,  233 => 119,  227 => 116,  221 => 113,  210 => 105,  204 => 102,  198 => 99,  189 => 93,  183 => 90,  177 => 87,  168 => 81,  162 => 78,  156 => 75,  147 => 69,  141 => 66,  135 => 63,  126 => 57,  120 => 54,  114 => 51,  105 => 45,  99 => 42,  93 => 39,  86 => 34,  82 => 31,  79 => 30,  73 => 28,  67 => 26,  64 => 25,  62 => 24,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::subadmin.html.twig' %}

{% block body %}

    <h2>User Profile</h2> <br/>
    <div class=\"row\">
        <div class=\"col-md-12\">
            <div class=\"panel panel-primary\" data-collapsed=\"0\">
                <div class=\"panel-heading\">
                    <div class=\"panel-title\">
                        Profile
                    </div>
                    <div class=\"panel-options\"> <a href=\"#\" data-rel=\"collapse\"><i
                                    class=\"entypo-down-open\"></i></a> <a href=\"#\" data-rel=\"reload\"><i
                                    class=\"entypo-arrows-ccw\"></i></a> <a href=\"#\" data-rel=\"close\"><i
                                    class=\"entypo-cancel\"></i></a></div>
                </div>
                <div class=\"panel-body\">
                    <form action=\"\" method=\"post\" enctype=\"multipart/form-data\" role=\"form\" class=\"form-horizontal form-groups-bordered\">


                        <div class=\"form-group\">
                            <div class=\"col-sm-3\">
                                {% if Users.approve == 1 %}
                                    {% if Users.privacy == 1 %}
                                        <img src=\"{{ asset('bundles/assets/icon.png') }}\" style=\"width: 100px; height: 100px;\" alt=\"\">
                                    {% else %}
                                        <img src=\"{{ asset(Users.Upic) }}\" style=\"width: 100%;\" alt=\"\">
                                    {% endif %}
                                {% endif %}
                            </div>
                            <div class=\"col-sm-9\">
                                {#<input type=\"text\" name=\"name\" value=\"{{ UserData.Uname }}\" placeholder=\"Full Name\" class=\"form-control\">#}
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Uname }}\" readonly class=\"form-control\">
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" readonly value=\"{{ Users.Uphone }}\" class=\"form-control\">
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"password\" value=\"{{ Users.password }}\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Ugender }}\" class=\"form-control\" readonly>
                            </div>
                            <div class=\"col-sm-4\">
                                    <input type=\"text\" value=\"{{ Users.UMartialStatus }}\" class=\"form-control\" readonly>
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Color }}\" class=\"form-control\" readonly>
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Uage }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Uheight }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Education.name }}\" class=\"form-control\" readonly>
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Ujobbusinesstitle }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Ujobbusiness }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Ocupation.name }}\" class=\"form-control\" readonly>
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Uincome }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Religion.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Caste.name }}\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.UBodyType }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.URide }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Bearhijab }}\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <h3>Family details</h3>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Ufatherocupation.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Umotherocupation.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Umothertongue }}\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-3\">
                                <input type=\"text\" value=\"{{ Users.Ubrothers }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-3\">
                                <input type=\"text\" value=\"{{ Users.Usisters }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-3\">
                                <input type=\"text\" value=\"{{ Users.Umarriedbrothers }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-3\">
                                <input type=\"text\" value=\"{{ Users.Umarriedsisters }}\" readonly class=\"form-control\" >
                            </div>
                        </div>


                        <h3>Residence</h3>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.UAccommodation }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.UAccommodationStatus }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Uhousesize }}\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Country.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.State.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.City.name }}\" readonly class=\"form-control\" >
                            </div>
                        </div>


                        <h3>Life partner Requirements</h3>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Lpminage }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Lpmaxage }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Lpheight }}\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Lpcountry.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Lpstate.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Lpcity.name }}\" readonly class=\"form-control\" >
                            </div>
                        </div>

                        <div class=\"form-group\">
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Lpreligion.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <input type=\"text\" value=\"{{ Users.Lpcaste.name }}\" readonly class=\"form-control\" >
                            </div>
                            <div class=\"col-sm-4\">
                                <textarea class=\"form-control\" readonly>{{ Users.Lpmessage }}</textarea>
                            </div>
                        </div>
                        {#<div class=\"form-group\">
                            <div class=\"col-sm-6 col-sm-offset-3\" style=\"text-align: center;\">
                                <button type=\"submit\" class=\"btn btn-info btn-lg\">Register</button>
                            </div>
                        </div>#}
                    </form>
                </div>
            </div>
        </div>
    </div>
    <br><br><br><br><br>
    <br><br><br><br><br>

    <script>
        \$(document).ready(function () {
            \$(\"#caste\").prop( \"disabled\", true );
            \$(\"#rstate\").prop( \"disabled\", true );
            \$(\"#rcity\").prop( \"disabled\", true );
            \$(\"#lpstate\").prop( \"disabled\", true );
            \$(\"#lpcity\").prop( \"disabled\", true );
            \$(\"#lpcaste\").prop( \"disabled\", true );
        });

    </script>
{% endblock %}", "SubAdminBundle:Users:Profileothers.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\SubadminBundle/Resources/views/Users/Profileothers.html.twig");
    }
}
