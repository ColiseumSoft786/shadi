<?php

/* AdminBundle:Admin/Sidebar:SubAdminMembers.html.twig */
class __TwigTemplate_026def531aa5f2e5e8e681d8e67de3b28f40b5cf2e2f724dc580fbecf1d67edd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Admin/Sidebar:SubAdminMembers.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5de2ad2bd30c2ec26c0cdcbe6ea45a64a436c65671640429781c7442c96882af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5de2ad2bd30c2ec26c0cdcbe6ea45a64a436c65671640429781c7442c96882af->enter($__internal_5de2ad2bd30c2ec26c0cdcbe6ea45a64a436c65671640429781c7442c96882af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Sidebar:SubAdminMembers.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5de2ad2bd30c2ec26c0cdcbe6ea45a64a436c65671640429781c7442c96882af->leave($__internal_5de2ad2bd30c2ec26c0cdcbe6ea45a64a436c65671640429781c7442c96882af_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_f12943f87ca375aa3910e67ca5317b5a228c1ab898560a7c6b3830605cbc87ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f12943f87ca375aa3910e67ca5317b5a228c1ab898560a7c6b3830605cbc87ef->enter($__internal_f12943f87ca375aa3910e67ca5317b5a228c1ab898560a7c6b3830605cbc87ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    ";
        // line 6
        echo "    <script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>
    ";
        // line 116
        echo "    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4>Sub Admin Members</h4>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Picture</th>
            <th>Userid</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 194
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["SAdminUsers"] ?? $this->getContext($context, "SAdminUsers")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 195
            echo "            ";
            if ((($this->getAttribute($context["item"], "subadmin", array()) != null) && ($this->getAttribute($context["item"], "block", array()) != 2))) {
                // line 196
                echo "            <tr class=\"odd gradeX\">
                ";
                // line 197
                if (($this->getAttribute($context["item"], "approve", array()) == 1)) {
                    // line 198
                    echo "                    <td> &nbsp; <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($this->getAttribute($context["item"], "upic", array())), "html", null, true);
                    echo "\" style=\"width: 60px; height: 60px;\" alt=\"\"></td>
                ";
                } else {
                    // line 200
                    echo "                    <td> &nbsp; Pending </td>
                ";
                }
                // line 202
                echo "                <td style=\"vertical-align: middle;\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "userid", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 203
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uname", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 204
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uphone", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 205
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "umartialstatus", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 206
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uage", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 207
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "country", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 208
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "state", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 209
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "city", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 210
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "religion", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 211
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "caste", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\">";
                // line 212
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "startdate", array()), "html", null, true);
                echo "</td>
                ";
                // line 213
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->controller("AdminBundle:Sidebar:AdminUserPackagePartialView", array("id" => $this->getAttribute(                // line 214
$context["item"], "id", array()))));
                // line 215
                echo "
            </tr>
            ";
            }
            // line 218
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 219
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>Picture</th>
            <th>Userid</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_f12943f87ca375aa3910e67ca5317b5a228c1ab898560a7c6b3830605cbc87ef->leave($__internal_f12943f87ca375aa3910e67ca5317b5a228c1ab898560a7c6b3830605cbc87ef_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Sidebar:SubAdminMembers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  315 => 219,  309 => 218,  304 => 215,  302 => 214,  301 => 213,  297 => 212,  293 => 211,  289 => 210,  285 => 209,  281 => 208,  277 => 207,  273 => 206,  269 => 205,  265 => 204,  261 => 203,  256 => 202,  252 => 200,  246 => 198,  244 => 197,  241 => 196,  238 => 195,  234 => 194,  154 => 116,  43 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::admin.html.twig' %}

{% block body %}

    {#filtration scripts#}
    <script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>
    {#filtration scripts#}
    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4>Sub Admin Members</h4>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Picture</th>
            <th>Userid</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        {% for item in SAdminUsers %}
            {% if item.subadmin != null and item.block != 2 %}
            <tr class=\"odd gradeX\">
                {% if item.approve == 1 %}
                    <td> &nbsp; <img src=\"{{ asset(item.upic) }}\" style=\"width: 60px; height: 60px;\" alt=\"\"></td>
                {% else %}
                    <td> &nbsp; Pending </td>
                {% endif %}
                <td style=\"vertical-align: middle;\">{{ item.userid }}</td>
                <td style=\"vertical-align: middle;\">{{ item.uname }}</td>
                <td style=\"vertical-align: middle;\">{{ item.uphone }}</td>
                <td style=\"vertical-align: middle;\">{{ item.umartialstatus }}</td>
                <td style=\"vertical-align: middle;\">{{ item.uage }}</td>
                <td style=\"vertical-align: middle;\">{{ item.country.name }}</td>
                <td style=\"vertical-align: middle;\">{{ item.state.name }}</td>
                <td style=\"vertical-align: middle;\">{{ item.city.name }}</td>
                <td style=\"vertical-align: middle;\">{{ item.religion.name }}</td>
                <td style=\"vertical-align: middle;\">{{ item.caste.name }}</td>
                <td style=\"vertical-align: middle;\">{{ item.startdate }}</td>
                {{ render(controller(
                    'AdminBundle:Sidebar:AdminUserPackagePartialView',{'id':item.id}
                )) }}
            </tr>
            {% endif %}
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>Picture</th>
            <th>Userid</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "AdminBundle:Admin/Sidebar:SubAdminMembers.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Sidebar/SubAdminMembers.html.twig");
    }
}
