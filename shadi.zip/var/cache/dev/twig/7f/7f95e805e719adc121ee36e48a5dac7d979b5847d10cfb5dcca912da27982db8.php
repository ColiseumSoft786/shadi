<?php

/* AdminBundle:Admin/Sidebar:PackagePartial.html.twig */
class __TwigTemplate_e1b68869669a96d13eb90954e5aaf633d1edfcfbf3345fc9d4e32ea797ed3ec7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19612a37199009526ab8e96e332dd38c6ee2fbf7fdd60b2c138d716fb1fa1117 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19612a37199009526ab8e96e332dd38c6ee2fbf7fdd60b2c138d716fb1fa1117->enter($__internal_19612a37199009526ab8e96e332dd38c6ee2fbf7fdd60b2c138d716fb1fa1117_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Sidebar:PackagePartial.html.twig"));

        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Expire"] ?? $this->getContext($context, "Expire")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 2
            echo "    ";
            if (($this->getAttribute($context["item"], "status", array()) != 1)) {
                // line 3
                echo "        <td style=\"vertical-align: middle;\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "package", array()), "Name", array()), "html", null, true);
                echo "</td>
        <td style=\"vertical-align: middle;\"> ";
                // line 4
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "Expiredate", array()), "html", null, true);
                echo "</td>
    ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_19612a37199009526ab8e96e332dd38c6ee2fbf7fdd60b2c138d716fb1fa1117->leave($__internal_19612a37199009526ab8e96e332dd38c6ee2fbf7fdd60b2c138d716fb1fa1117_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Sidebar:PackagePartial.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 4,  29 => 3,  26 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% for item in Expire %}
    {% if item.status != 1 %}
        <td style=\"vertical-align: middle;\"> {{ item.package.Name }}</td>
        <td style=\"vertical-align: middle;\"> {{ item.Expiredate }}</td>
    {% endif %}
{% endfor %}", "AdminBundle:Admin/Sidebar:PackagePartial.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Sidebar/PackagePartial.html.twig");
    }
}
