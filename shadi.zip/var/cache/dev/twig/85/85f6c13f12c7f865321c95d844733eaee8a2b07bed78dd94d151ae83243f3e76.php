<?php

/* ::admin.html.twig */
class __TwigTemplate_40f5b8b52f81bd0f3aa9b87a544d4a2d9eea077b98e2ccf62bee8053d80c7eac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'dashboard_active' => array($this, 'block_dashboard_active'),
            'users_active' => array($this, 'block_users_active'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e63ba4789174ff1e48657784702706dba1dca4f9ebd062f0c831e3bea0c1e3c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e63ba4789174ff1e48657784702706dba1dca4f9ebd062f0c831e3bea0c1e3c1->enter($__internal_e63ba4789174ff1e48657784702706dba1dca4f9ebd062f0c831e3bea0c1e3c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::admin.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<meta http-equiv=\"content-type\" content=\"text/html;charset=UTF-8\"/><!-- /Added by HTTrack -->
<head>
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <meta name=\"description\" content=\"Neon Admin Panel\"/>
    <meta name=\"author\" content=\"Laborator.co\"/>
    <link rel=\"icon\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(""), "html", null, true);
        echo "assets/images/favicon.ico\">
    <title>Rishta | ";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css\" id=\"style-resource-1\">
    <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/font-icons/entypo/css/entypo.css\" id=\"style-resource-2\">
    <link rel=\"stylesheet\" href=\"http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic\" id=\"style-resource-3\">

    <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/font-icons/font-awesome/css/font-awesome.min.css\" id=\"style-resource-4\">
    <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/bootstrap.css\" id=\"style-resource-4\">
    <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-core.css\" id=\"style-resource-5\">
    <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-theme.css\" id=\"style-resource-6\">
    <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-forms.css\" id=\"style-resource-7\">
    <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/custom.css\" id=\"style-resource-8\">
    <link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/skins/purple.css\" id=\"style-resource-8\">
    <script src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-1.11.3.min.js\"></script>
    <script src=\"https://demo.neontheme.com/assets/js/ie8-responsive-file-warning.js\"></script><![endif]-->
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script> <![endif]-->



<body class=\"page-body page-fade\" data-url=\"https://demo.neontheme.com\">
<div class=\"page-container\">
    <div class=\"sidebar-menu\">
        <div class=\"sidebar-menu-inner\">
            <header class=\"logo-env\"> <!-- logo -->
                <div class=\"logo\"><a href=\"\" style=\"font-size: 25px;\"> Shadi Online </a></div> <!-- logo collapse icon -->
                <div class=\"sidebar-collapse\"><a href=\"#\" class=\"sidebar-collapse-icon\">
                        <!-- add class \"with-animation\" if you want sidebar to have animation during expanding/collapsing transition -->
                        <i class=\"entypo-menu\"></i> </a></div>
                <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
                <div class=\"sidebar-mobile-menu visible-xs\"><a href=\"#\" class=\"with-animation\">
                        <!-- add class \"with-animation\" to support animation --> <i class=\"entypo-menu\"></i> </a></div>
            </header>
            <ul id=\"main-menu\" class=\"main-menu\">
                <li class=\"";
        // line 45
        $this->displayBlock('dashboard_active', $context, $blocks);
        echo "\"><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\"><i class=\"entypo-gauge\"></i><span
                                class=\"title\">Dashboard</span></a>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"entypo-users\"></i><span class=\"title\">Matrimony Members</span></a>
                    <ul>
                        <li><a href=\"";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("all_members");
        echo "\"><span class=\"title\">All Members</span></a></li>
                        <li><a href=\"";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("subadmin_members");
        echo "\"><span class=\"title\">Sub Admin Members</span></a></li>
                        <li><a href=\"";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("without_subadmin_members");
        echo "\"><span class=\"title\">Without Admin Members</span></a></li>
                    </ul>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"fa fa-cubes\"></i><span class=\"title\">Packages</span></a>
                    <ul>
                        <li><a href=\"";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_package_insert");
        echo "\"><span class=\"title\">Add Packages</span></a></li>
                        <li><a href=\"";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_packages");
        echo "\"><span class=\"title\">View Packages</span></a></li>
                    </ul>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"entypo-user-add\"></i><span class=\"title\">Staff Management</span></a>
                    <ul>
                        <li><a href=\"";
        // line 66
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_subadmin_insert");
        echo "\"><span class=\"title\">Add Sub Admins</span></a></li>
                        <li><a href=\"";
        // line 67
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_subadmins");
        echo "\"><span class=\"title\">View Sub Admins</span></a></li>
                    </ul>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"entypo-cog\"></i><span class=\"title\">Settings</span></a>
                    <ul>
                        <li><a href=\"";
        // line 73
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_countries");
        echo "\"><span class=\"title\">Country</span></a></li>
                        <li><a href=\"";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_states");
        echo "\"><span class=\"title\">State</span></a></li>
                        <li><a href=\"";
        // line 75
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_cities");
        echo "\"><span class=\"title\">City</span></a></li>
                        <li><a href=\"";
        // line 76
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_education");
        echo "\"><span class=\"title\">Education</span></a></li>
                        <li><a href=\"";
        // line 77
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_ocupations");
        echo "\"><span class=\"title\">Ocupation</span></a></li>
                        <li><a href=\"";
        // line 78
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_religions");
        echo "\"><span class=\"title\">Religion</span></a></li>
                        <li><a href=\"";
        // line 79
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_castes");
        echo "\"><span class=\"title\">Caste</span></a></li>
                    </ul>
                </li>
                <li class=\"";
        // line 82
        $this->displayBlock('users_active', $context, $blocks);
        echo "\"><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admins_logout");
        echo "\"><i class=\"entypo-logout\"></i><span class=\"title\">Sign Out</span></a></li>
            </ul>
        </div>
    </div>
    <div class=\"main-content\">
        <!-- TS15383785128609: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates -->
        <div class=\"row\"> <!-- Profile Info and Notifications -->
            <div class=\"col-md-6 col-sm-8 clearfix\">
                <h1>Super Admin Panel</h1>
            </div> <!-- Raw Links -->
            <div class=\"col-md-6 col-sm-4 clearfix hidden-xs\">
                <ul class=\"list-inline links-list pull-right\">
                    <li><a href=\"";
        // line 94
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admins_logout");
        echo "\">
                            Log Out <i class=\"entypo-logout right\"></i> </a></li>
                </ul>
            </div>
        </div>
        <hr/>
        <br/>
        ";
        // line 101
        $this->displayBlock('body', $context, $blocks);
        // line 103
        echo "

        <!-- Footer -->
        <footer class=\"main\">

            &copy; 2018 <strong>Shadi Online</strong> Admin Theme by <a href=\"https://coliseumsoft.com/\"
                                                                   target=\"_blank\">Coliseum Soft</a></footer>
    </div>
    <!-- TS153837851214942: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates -->
    <div id=\"chat\" class=\"fixed\" data-current-user=\"Art Ramadani\" data-order-by-status=\"1\" data-max-chat-history=\"25\">
        <div class=\"chat-inner\"><h2 class=\"chat-header\"><a href=\"#\" class=\"chat-close\"><i class=\"entypo-cancel\"></i></a>
                <i class=\"entypo-users\"></i>
                Chat
                <span class=\"badge badge-success is-hidden\">0</span></h2>
            <div class=\"chat-group\" id=\"group-1\"><strong>Favorites</strong> <a href=\"#\" id=\"sample-user-123\"
                                                                               data-conversation-history=\"#sample_history\"><span
                            class=\"user-status is-online\"></span> <em>Catherine J. Watkins</em></a> <a href=\"#\"><span
                            class=\"user-status is-online\"></span> <em>Nicholas R. Walker</em></a> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Susan J. Best</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Brandon S. Young</em></a> <a href=\"#\"><span
                            class=\"user-status is-idle\"></span> <em>Fernando G. Olson</em></a></div>
            <div class=\"chat-group\" id=\"group-2\"><strong>Work</strong> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Robert J. Garcia</em></a> <a href=\"#\"
                                                                                                    data-conversation-history=\"#sample_history_2\"><span
                            class=\"user-status is-offline\"></span> <em>Daniel A. Pena</em></a> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Rodrigo E. Lozano</em></a></div>
            <div class=\"chat-group\" id=\"group-3\"><strong>Social</strong> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Velma G. Pearson</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Margaret R. Dedmon</em></a> <a href=\"#\"><span
                            class=\"user-status is-online\"></span> <em>Kathleen M. Canales</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Tracy J. Rodriguez</em></a></div>
        </div> <!-- conversation template -->
        <div class=\"chat-conversation\">
            <div class=\"conversation-header\"><a href=\"#\" class=\"conversation-close\"><i class=\"entypo-cancel\"></i></a>
                <span class=\"user-status\"></span> <span class=\"display-name\"></span>
                <small></small>
            </div>
            <ul class=\"conversation-body\"></ul>
            <div class=\"chat-textarea\"><textarea class=\"form-control autogrow\"
                                                 placeholder=\"Type your message\"></textarea></div>
        </div>
    </div> <!-- Chat Histories -->
    <ul class=\"chat-history\" id=\"sample_history\">
        <li><span class=\"user\">Art Ramadani</span>
            <p>Are you here?</p> <span class=\"time\">09:00</span></li>
        <li class=\"opponent\"><span class=\"user\">Catherine J. Watkins</span>
            <p>This message is pre-queued.</p> <span class=\"time\">09:25</span></li>
        <li class=\"opponent\"><span class=\"user\">Catherine J. Watkins</span>
            <p>Whohoo!</p> <span class=\"time\">09:26</span></li>
        <li class=\"opponent unread\"><span class=\"user\">Catherine J. Watkins</span>
            <p>Do you like it?</p> <span class=\"time\">09:27</span></li>
    </ul> <!-- Chat Histories -->
    <ul class=\"chat-history\" id=\"sample_history_2\">
        <li class=\"opponent unread\"><span class=\"user\">Daniel A. Pena</span>
            <p>I am going out.</p> <span class=\"time\">08:21</span></li>
        <li class=\"opponent unread\"><span class=\"user\">Daniel A. Pena</span>
            <p>Call me when you see this message.</p> <span class=\"time\">08:27</span></li>
    </ul>
</div>
<!-- Sample Modal (Default skin) -->
<div class=\"modal fade\" id=\"sample-modal-dialog-1\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Default Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Sample Modal (Skin inverted) -->
<div class=\"modal invert fade\" id=\"sample-modal-dialog-2\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Inverted Skin Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Sample Modal (Skin gray) -->
<div class=\"modal gray fade\" id=\"sample-modal-dialog-3\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Gray Skin Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Imported styles on this page -->
<link rel=\"stylesheet\" href=\"";
        // line 214
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/datatables/datatables.css\" id=\"style-resource-1\">

<link rel=\"stylesheet\" href=\"";
        // line 216
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/select2/select2-bootstrap.css\" id=\"style-resource-2\">
<link rel=\"stylesheet\" href=\"";
        // line 217
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/select2/select2.css\" id=\"style-resource-3\">
<link rel=\"stylesheet\" href=\"";
        // line 218
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jvectormap/jquery-jvectormap-1.2.2.css\" id=\"style-resource-1\">
<link rel=\"stylesheet\" href=\"";
        // line 219
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/rickshaw/rickshaw.min.css\" id=\"style-resource-2\">
<script src=\"";
        // line 220
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/gsap/TweenMax.min.js\" id=\"script-resource-1\"></script>
<script src=\"";
        // line 221
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js\" id=\"script-resource-2\"></script>
<script src=\"";
        // line 222
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/bootstrap.js\" id=\"script-resource-3\"></script>
<script src=\"";
        // line 223
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/joinable.js\" id=\"script-resource-4\"></script>
<script src=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/resizeable.js\" id=\"script-resource-5\"></script>
<script src=\"";
        // line 225
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-api.js\" id=\"script-resource-6\"></script>
<script src=\"";
        // line 226
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/cookies.min.js\" id=\"script-resource-7\"></script>
<script src=\"";
        // line 227
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/bootstrap-switch.min.js\" id=\"script-resource-8\"></script>
<script src=\"";
        // line 228
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jvectormap/jquery-jvectormap-1.2.2.min.js\" id=\"script-resource-8\"></script>
<script src=\"";
        // line 229
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jvectormap/jquery-jvectormap-europe-merc-en.js\" id=\"script-resource-9\"></script>
<script src=\"";
        // line 230
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery.sparkline.min.js\" id=\"script-resource-10\"></script>
<script src=\"";
        // line 231
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/rickshaw/vendor/d3.v3.js\" id=\"script-resource-11\"></script>
<script src=\"";
        // line 232
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/rickshaw/rickshaw.min.js\" id=\"script-resource-12\"></script>
<script src=\"";
        // line 233
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/raphael-min.js\" id=\"script-resource-13\"></script>
<script src=\"";
        // line 234
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/morris.min.js\" id=\"script-resource-14\"></script>
<script src=\"";
        // line 235
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/toastr.js\" id=\"script-resource-15\"></script>
<script src=\"";
        // line 236
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-chat.js\" id=\"script-resource-16\"></script>

<script src=\"";
        // line 238
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/datatables/datatables.js\" id=\"script-resource-8\"></script>
<script src=\"";
        // line 239
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/select2/select2.min.js\" id=\"script-resource-9\"></script>
<!-- JavaScripts initializations and stuff -->
<script src=\"";
        // line 241
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-custom.js\" id=\"script-resource-17\"></script> <!-- Demo Settings -->
<script src=\"";
        // line 242
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-demo.js\" id=\"script-resource-18\"></script>
<script src=\"";
        // line 243
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-skins.js\" id=\"script-resource-19\"></script>


<script type=\"text/javascript\">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-28991003-7']);
    _gaq.push(['_setDomainName', 'demo.neontheme.com']);
    _gaq.push(['_trackPageview']);
    (function () {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();
</script>
</body>
</html>";
        
        $__internal_e63ba4789174ff1e48657784702706dba1dca4f9ebd062f0c831e3bea0c1e3c1->leave($__internal_e63ba4789174ff1e48657784702706dba1dca4f9ebd062f0c831e3bea0c1e3c1_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_a8daa22f29d3d4bfa1a6d7c088ddec7a8fc05b9001b2e06531a8d489e885ddf1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8daa22f29d3d4bfa1a6d7c088ddec7a8fc05b9001b2e06531a8d489e885ddf1->enter($__internal_a8daa22f29d3d4bfa1a6d7c088ddec7a8fc05b9001b2e06531a8d489e885ddf1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_a8daa22f29d3d4bfa1a6d7c088ddec7a8fc05b9001b2e06531a8d489e885ddf1->leave($__internal_a8daa22f29d3d4bfa1a6d7c088ddec7a8fc05b9001b2e06531a8d489e885ddf1_prof);

    }

    // line 45
    public function block_dashboard_active($context, array $blocks = array())
    {
        $__internal_2f85fbd614295aafaa764a72d17157a92ef370446e6331493094731324843aa4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f85fbd614295aafaa764a72d17157a92ef370446e6331493094731324843aa4->enter($__internal_2f85fbd614295aafaa764a72d17157a92ef370446e6331493094731324843aa4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dashboard_active"));

        
        $__internal_2f85fbd614295aafaa764a72d17157a92ef370446e6331493094731324843aa4->leave($__internal_2f85fbd614295aafaa764a72d17157a92ef370446e6331493094731324843aa4_prof);

    }

    // line 82
    public function block_users_active($context, array $blocks = array())
    {
        $__internal_43131f1839438829d93d3327b842e51c3df550ae16e23f83e2fd012827795369 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43131f1839438829d93d3327b842e51c3df550ae16e23f83e2fd012827795369->enter($__internal_43131f1839438829d93d3327b842e51c3df550ae16e23f83e2fd012827795369_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "users_active"));

        
        $__internal_43131f1839438829d93d3327b842e51c3df550ae16e23f83e2fd012827795369->leave($__internal_43131f1839438829d93d3327b842e51c3df550ae16e23f83e2fd012827795369_prof);

    }

    // line 101
    public function block_body($context, array $blocks = array())
    {
        $__internal_c7eb47b5725086d322877b7faee39c8986c280db701d7695f0908ee34b5ab3da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7eb47b5725086d322877b7faee39c8986c280db701d7695f0908ee34b5ab3da->enter($__internal_c7eb47b5725086d322877b7faee39c8986c280db701d7695f0908ee34b5ab3da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 102
        echo "        ";
        
        $__internal_c7eb47b5725086d322877b7faee39c8986c280db701d7695f0908ee34b5ab3da->leave($__internal_c7eb47b5725086d322877b7faee39c8986c280db701d7695f0908ee34b5ab3da_prof);

    }

    public function getTemplateName()
    {
        return "::admin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  506 => 102,  500 => 101,  489 => 82,  478 => 45,  467 => 12,  441 => 243,  437 => 242,  433 => 241,  428 => 239,  424 => 238,  419 => 236,  415 => 235,  411 => 234,  407 => 233,  403 => 232,  399 => 231,  395 => 230,  391 => 229,  387 => 228,  383 => 227,  379 => 226,  375 => 225,  371 => 224,  367 => 223,  363 => 222,  359 => 221,  355 => 220,  351 => 219,  347 => 218,  343 => 217,  339 => 216,  334 => 214,  221 => 103,  219 => 101,  209 => 94,  192 => 82,  186 => 79,  182 => 78,  178 => 77,  174 => 76,  170 => 75,  166 => 74,  162 => 73,  153 => 67,  149 => 66,  140 => 60,  136 => 59,  127 => 53,  123 => 52,  119 => 51,  108 => 45,  84 => 24,  80 => 23,  76 => 22,  72 => 21,  68 => 20,  64 => 19,  60 => 18,  56 => 17,  50 => 14,  46 => 13,  42 => 12,  38 => 11,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">

<meta http-equiv=\"content-type\" content=\"text/html;charset=UTF-8\"/><!-- /Added by HTTrack -->
<head>
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <meta name=\"description\" content=\"Neon Admin Panel\"/>
    <meta name=\"author\" content=\"Laborator.co\"/>
    <link rel=\"icon\" href=\"{{ asset('') }}assets/images/favicon.ico\">
    <title>Rishta | {% block title %}{% endblock %}</title>
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css\" id=\"style-resource-1\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/font-icons/entypo/css/entypo.css\" id=\"style-resource-2\">
    <link rel=\"stylesheet\" href=\"http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic\" id=\"style-resource-3\">

    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/font-icons/font-awesome/css/font-awesome.min.css\" id=\"style-resource-4\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/bootstrap.css\" id=\"style-resource-4\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-core.css\" id=\"style-resource-5\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-theme.css\" id=\"style-resource-6\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-forms.css\" id=\"style-resource-7\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/custom.css\" id=\"style-resource-8\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/skins/purple.css\" id=\"style-resource-8\">
    <script src=\"{{ asset('bundles/') }}assets/js/jquery-1.11.3.min.js\"></script>
    <script src=\"https://demo.neontheme.com/assets/js/ie8-responsive-file-warning.js\"></script><![endif]-->
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script> <![endif]-->



<body class=\"page-body page-fade\" data-url=\"https://demo.neontheme.com\">
<div class=\"page-container\">
    <div class=\"sidebar-menu\">
        <div class=\"sidebar-menu-inner\">
            <header class=\"logo-env\"> <!-- logo -->
                <div class=\"logo\"><a href=\"\" style=\"font-size: 25px;\"> Shadi Online </a></div> <!-- logo collapse icon -->
                <div class=\"sidebar-collapse\"><a href=\"#\" class=\"sidebar-collapse-icon\">
                        <!-- add class \"with-animation\" if you want sidebar to have animation during expanding/collapsing transition -->
                        <i class=\"entypo-menu\"></i> </a></div>
                <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
                <div class=\"sidebar-mobile-menu visible-xs\"><a href=\"#\" class=\"with-animation\">
                        <!-- add class \"with-animation\" to support animation --> <i class=\"entypo-menu\"></i> </a></div>
            </header>
            <ul id=\"main-menu\" class=\"main-menu\">
                <li class=\"{%  block dashboard_active %}{% endblock %}\"><a href=\"{{ path('admin_index') }}\"><i class=\"entypo-gauge\"></i><span
                                class=\"title\">Dashboard</span></a>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"entypo-users\"></i><span class=\"title\">Matrimony Members</span></a>
                    <ul>
                        <li><a href=\"{{ path('all_members') }}\"><span class=\"title\">All Members</span></a></li>
                        <li><a href=\"{{ path('subadmin_members') }}\"><span class=\"title\">Sub Admin Members</span></a></li>
                        <li><a href=\"{{ path('without_subadmin_members') }}\"><span class=\"title\">Without Admin Members</span></a></li>
                    </ul>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"fa fa-cubes\"></i><span class=\"title\">Packages</span></a>
                    <ul>
                        <li><a href=\"{{ path('admin_package_insert') }}\"><span class=\"title\">Add Packages</span></a></li>
                        <li><a href=\"{{ path('admin_packages') }}\"><span class=\"title\">View Packages</span></a></li>
                    </ul>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"entypo-user-add\"></i><span class=\"title\">Staff Management</span></a>
                    <ul>
                        <li><a href=\"{{ path('admin_subadmin_insert') }}\"><span class=\"title\">Add Sub Admins</span></a></li>
                        <li><a href=\"{{ path('admin_subadmins') }}\"><span class=\"title\">View Sub Admins</span></a></li>
                    </ul>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"entypo-cog\"></i><span class=\"title\">Settings</span></a>
                    <ul>
                        <li><a href=\"{{ path('admin_countries') }}\"><span class=\"title\">Country</span></a></li>
                        <li><a href=\"{{ path('admin_states') }}\"><span class=\"title\">State</span></a></li>
                        <li><a href=\"{{ path('admin_cities') }}\"><span class=\"title\">City</span></a></li>
                        <li><a href=\"{{ path('admin_education') }}\"><span class=\"title\">Education</span></a></li>
                        <li><a href=\"{{ path('admin_ocupations') }}\"><span class=\"title\">Ocupation</span></a></li>
                        <li><a href=\"{{ path('admin_religions') }}\"><span class=\"title\">Religion</span></a></li>
                        <li><a href=\"{{ path('admin_castes') }}\"><span class=\"title\">Caste</span></a></li>
                    </ul>
                </li>
                <li class=\"{% block users_active %}{% endblock %}\"><a href=\"{{ path('admins_logout') }}\"><i class=\"entypo-logout\"></i><span class=\"title\">Sign Out</span></a></li>
            </ul>
        </div>
    </div>
    <div class=\"main-content\">
        <!-- TS15383785128609: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates -->
        <div class=\"row\"> <!-- Profile Info and Notifications -->
            <div class=\"col-md-6 col-sm-8 clearfix\">
                <h1>Super Admin Panel</h1>
            </div> <!-- Raw Links -->
            <div class=\"col-md-6 col-sm-4 clearfix hidden-xs\">
                <ul class=\"list-inline links-list pull-right\">
                    <li><a href=\"{{ path('admins_logout') }}\">
                            Log Out <i class=\"entypo-logout right\"></i> </a></li>
                </ul>
            </div>
        </div>
        <hr/>
        <br/>
        {% block body %}
        {% endblock %}


        <!-- Footer -->
        <footer class=\"main\">

            &copy; 2018 <strong>Shadi Online</strong> Admin Theme by <a href=\"https://coliseumsoft.com/\"
                                                                   target=\"_blank\">Coliseum Soft</a></footer>
    </div>
    <!-- TS153837851214942: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates -->
    <div id=\"chat\" class=\"fixed\" data-current-user=\"Art Ramadani\" data-order-by-status=\"1\" data-max-chat-history=\"25\">
        <div class=\"chat-inner\"><h2 class=\"chat-header\"><a href=\"#\" class=\"chat-close\"><i class=\"entypo-cancel\"></i></a>
                <i class=\"entypo-users\"></i>
                Chat
                <span class=\"badge badge-success is-hidden\">0</span></h2>
            <div class=\"chat-group\" id=\"group-1\"><strong>Favorites</strong> <a href=\"#\" id=\"sample-user-123\"
                                                                               data-conversation-history=\"#sample_history\"><span
                            class=\"user-status is-online\"></span> <em>Catherine J. Watkins</em></a> <a href=\"#\"><span
                            class=\"user-status is-online\"></span> <em>Nicholas R. Walker</em></a> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Susan J. Best</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Brandon S. Young</em></a> <a href=\"#\"><span
                            class=\"user-status is-idle\"></span> <em>Fernando G. Olson</em></a></div>
            <div class=\"chat-group\" id=\"group-2\"><strong>Work</strong> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Robert J. Garcia</em></a> <a href=\"#\"
                                                                                                    data-conversation-history=\"#sample_history_2\"><span
                            class=\"user-status is-offline\"></span> <em>Daniel A. Pena</em></a> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Rodrigo E. Lozano</em></a></div>
            <div class=\"chat-group\" id=\"group-3\"><strong>Social</strong> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Velma G. Pearson</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Margaret R. Dedmon</em></a> <a href=\"#\"><span
                            class=\"user-status is-online\"></span> <em>Kathleen M. Canales</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Tracy J. Rodriguez</em></a></div>
        </div> <!-- conversation template -->
        <div class=\"chat-conversation\">
            <div class=\"conversation-header\"><a href=\"#\" class=\"conversation-close\"><i class=\"entypo-cancel\"></i></a>
                <span class=\"user-status\"></span> <span class=\"display-name\"></span>
                <small></small>
            </div>
            <ul class=\"conversation-body\"></ul>
            <div class=\"chat-textarea\"><textarea class=\"form-control autogrow\"
                                                 placeholder=\"Type your message\"></textarea></div>
        </div>
    </div> <!-- Chat Histories -->
    <ul class=\"chat-history\" id=\"sample_history\">
        <li><span class=\"user\">Art Ramadani</span>
            <p>Are you here?</p> <span class=\"time\">09:00</span></li>
        <li class=\"opponent\"><span class=\"user\">Catherine J. Watkins</span>
            <p>This message is pre-queued.</p> <span class=\"time\">09:25</span></li>
        <li class=\"opponent\"><span class=\"user\">Catherine J. Watkins</span>
            <p>Whohoo!</p> <span class=\"time\">09:26</span></li>
        <li class=\"opponent unread\"><span class=\"user\">Catherine J. Watkins</span>
            <p>Do you like it?</p> <span class=\"time\">09:27</span></li>
    </ul> <!-- Chat Histories -->
    <ul class=\"chat-history\" id=\"sample_history_2\">
        <li class=\"opponent unread\"><span class=\"user\">Daniel A. Pena</span>
            <p>I am going out.</p> <span class=\"time\">08:21</span></li>
        <li class=\"opponent unread\"><span class=\"user\">Daniel A. Pena</span>
            <p>Call me when you see this message.</p> <span class=\"time\">08:27</span></li>
    </ul>
</div>
<!-- Sample Modal (Default skin) -->
<div class=\"modal fade\" id=\"sample-modal-dialog-1\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Default Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Sample Modal (Skin inverted) -->
<div class=\"modal invert fade\" id=\"sample-modal-dialog-2\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Inverted Skin Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Sample Modal (Skin gray) -->
<div class=\"modal gray fade\" id=\"sample-modal-dialog-3\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Gray Skin Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Imported styles on this page -->
<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/datatables/datatables.css\" id=\"style-resource-1\">

<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/select2/select2-bootstrap.css\" id=\"style-resource-2\">
<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/select2/select2.css\" id=\"style-resource-3\">
<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/jvectormap/jquery-jvectormap-1.2.2.css\" id=\"style-resource-1\">
<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/rickshaw/rickshaw.min.css\" id=\"style-resource-2\">
<script src=\"{{ asset('bundles/') }}assets/js/gsap/TweenMax.min.js\" id=\"script-resource-1\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js\" id=\"script-resource-2\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/bootstrap.js\" id=\"script-resource-3\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/joinable.js\" id=\"script-resource-4\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/resizeable.js\" id=\"script-resource-5\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/neon-api.js\" id=\"script-resource-6\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/cookies.min.js\" id=\"script-resource-7\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/bootstrap-switch.min.js\" id=\"script-resource-8\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/jvectormap/jquery-jvectormap-1.2.2.min.js\" id=\"script-resource-8\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/jvectormap/jquery-jvectormap-europe-merc-en.js\" id=\"script-resource-9\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/jquery.sparkline.min.js\" id=\"script-resource-10\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/rickshaw/vendor/d3.v3.js\" id=\"script-resource-11\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/rickshaw/rickshaw.min.js\" id=\"script-resource-12\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/raphael-min.js\" id=\"script-resource-13\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/morris.min.js\" id=\"script-resource-14\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/toastr.js\" id=\"script-resource-15\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/neon-chat.js\" id=\"script-resource-16\"></script>

<script src=\"{{ asset('bundles/') }}assets/js/datatables/datatables.js\" id=\"script-resource-8\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/select2/select2.min.js\" id=\"script-resource-9\"></script>
<!-- JavaScripts initializations and stuff -->
<script src=\"{{ asset('bundles/') }}assets/js/neon-custom.js\" id=\"script-resource-17\"></script> <!-- Demo Settings -->
<script src=\"{{ asset('bundles/') }}assets/js/neon-demo.js\" id=\"script-resource-18\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/neon-skins.js\" id=\"script-resource-19\"></script>


<script type=\"text/javascript\">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-28991003-7']);
    _gaq.push(['_setDomainName', 'demo.neontheme.com']);
    _gaq.push(['_trackPageview']);
    (function () {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();
</script>
</body>
</html>", "::admin.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\app/Resources\\views/admin.html.twig");
    }
}
