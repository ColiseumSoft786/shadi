<?php

/* AdminBundle:Admin/Packages:packages.html.twig */
class __TwigTemplate_fbf2d7caf5e67c4960076e12952a17a18c66c15699ba24b12f664f7fcc4d9bdf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Admin/Packages:packages.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_261d4ae5f699cfe22b6e72c19f2836e5e68996d812a52c30d9a01f9e53c930e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_261d4ae5f699cfe22b6e72c19f2836e5e68996d812a52c30d9a01f9e53c930e7->enter($__internal_261d4ae5f699cfe22b6e72c19f2836e5e68996d812a52c30d9a01f9e53c930e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Packages:packages.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_261d4ae5f699cfe22b6e72c19f2836e5e68996d812a52c30d9a01f9e53c930e7->leave($__internal_261d4ae5f699cfe22b6e72c19f2836e5e68996d812a52c30d9a01f9e53c930e7_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_886e436d56f731d8dcd97d35fb26c8ade82020d52fd811a6ab7b9a41318b2414 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_886e436d56f731d8dcd97d35fb26c8ade82020d52fd811a6ab7b9a41318b2414->enter($__internal_886e436d56f731d8dcd97d35fb26c8ade82020d52fd811a6ab7b9a41318b2414_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4 style=\"padding: 10px 0px;\">Package</h4> <span><a href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_package_insert");
        echo "\" class=\"btn btn-info\">Add Package</a></span>

    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Month</th>
            <th>Interests</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Packages"] ?? $this->getContext($context, "Packages")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 45
            echo "            <tr class=\"odd gradeX\">
                <td> &nbsp; ";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</td>
                <td> &nbsp; ";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "price", array()), "html", null, true);
            echo "</td>
                <td> &nbsp; ";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "month", array()), "html", null, true);
            echo "</td>
                <td> &nbsp; ";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "interest", array()), "html", null, true);
            echo "</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"";
            // line 51
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_packages_update", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 55
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Month</th>
            <th>Interests</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_886e436d56f731d8dcd97d35fb26c8ade82020d52fd811a6ab7b9a41318b2414->leave($__internal_886e436d56f731d8dcd97d35fb26c8ade82020d52fd811a6ab7b9a41318b2414_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Packages:packages.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 55,  109 => 51,  104 => 49,  100 => 48,  96 => 47,  92 => 46,  89 => 45,  85 => 44,  69 => 31,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::admin.html.twig' %}

{% block body %}
    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4 style=\"padding: 10px 0px;\">Package</h4> <span><a href=\"{{ path('admin_package_insert') }}\" class=\"btn btn-info\">Add Package</a></span>

    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Month</th>
            <th>Interests</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        {% for item in Packages %}
            <tr class=\"odd gradeX\">
                <td> &nbsp; {{ item.name }}</td>
                <td> &nbsp; {{ item.price }}</td>
                <td> &nbsp; {{ item.month }}</td>
                <td> &nbsp; {{ item.interest }}</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"{{ path('admin_packages_update',{id:item.id}) }}\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Month</th>
            <th>Interests</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "AdminBundle:Admin/Packages:packages.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Packages/packages.html.twig");
    }
}
