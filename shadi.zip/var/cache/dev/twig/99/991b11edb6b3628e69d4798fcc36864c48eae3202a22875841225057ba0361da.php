<?php

/* SubAdminBundle:Users:Users.html.twig */
class __TwigTemplate_9aa977d1c2fc1a8f39d421b606ffc92a485b647d3f36a77946876158a7a35c53 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::subadmin.html.twig", "SubAdminBundle:Users:Users.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::subadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8aae038a33f9050f9e832fff2012e7affd0fd7f57a9d0897d159972ae09d0f78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8aae038a33f9050f9e832fff2012e7affd0fd7f57a9d0897d159972ae09d0f78->enter($__internal_8aae038a33f9050f9e832fff2012e7affd0fd7f57a9d0897d159972ae09d0f78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SubAdminBundle:Users:Users.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8aae038a33f9050f9e832fff2012e7affd0fd7f57a9d0897d159972ae09d0f78->leave($__internal_8aae038a33f9050f9e832fff2012e7affd0fd7f57a9d0897d159972ae09d0f78_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_07006d585993e243854180d44fd73312fad0e0e6cffa17ad5bcc14f8c3affdf5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07006d585993e243854180d44fd73312fad0e0e6cffa17ad5bcc14f8c3affdf5->enter($__internal_07006d585993e243854180d44fd73312fad0e0e6cffa17ad5bcc14f8c3affdf5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"col-md-12\" style=\"text-align: center; padding: 150px 0px 250px 0px;\">
        <h1 style=\" margin: 0 auto;\">Welcome To Dashboard!</h1>
    </div>
    ";
        // line 11
        echo "    ";
        // line 120
        echo "    ";
        // line 121
        echo "    ";
        // line 149
        echo "

    ";
        // line 172
        echo "
    ";
        // line 174
        echo "    ";
        
        $__internal_07006d585993e243854180d44fd73312fad0e0e6cffa17ad5bcc14f8c3affdf5->leave($__internal_07006d585993e243854180d44fd73312fad0e0e6cffa17ad5bcc14f8c3affdf5_prof);

    }

    public function getTemplateName()
    {
        return "SubAdminBundle:Users:Users.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 174,  55 => 172,  51 => 149,  49 => 121,  47 => 120,  45 => 11,  40 => 7,  34 => 6,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::subadmin.html.twig' %}




{% block body %}
    <div class=\"col-md-12\" style=\"text-align: center; padding: 150px 0px 250px 0px;\">
        <h1 style=\" margin: 0 auto;\">Welcome To Dashboard!</h1>
    </div>
    {#filtration scripts#}
    {#<script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>#}
    {#filtration scripts#}
    {#<div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>#}


    {#<script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>#}

    {#<h4>Users</h4>#}
    {#<table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        {% for item in Users %}
            {% if item.block != 2 %}
                <tr class=\"odd gradeX\" style=\"text-align: center;\">
                    <td> &nbsp; <img src=\"{{ asset(item.upic) }}\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    <td style=\"vertical-align: middle;\">{{ item.userid }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uname }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uphone }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.umartialstatus }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uage }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.country.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.state.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.city.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.religion.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.caste.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.startdate }}</td>
                    {{ render(controller(
                        'AdminBundle:Sidebar:AdminUserPackagePartialView',{'id':item.id}
                    )) }}
                    <td style=\"vertical-align: middle;\" class=\"col-md-3\">
                        <a href=\"{{ path('sub_admins_users_profile',{id:item.id}) }}\" title=\"View Profile\" class=\"btn btn-info\"> <i class=\"entypo-eye\"></i></a>
                        #}{#<a href=\"\" title=\"Profile Pic\" class=\"btn btn-success\"> <i class=\"entypo-picture\"></i></a>#}{#
                        {% if item.block == 0 %}
                            <a href=\"{{ path('sub_admin_user_block_users',{id:item.id}) }}\" title=\"Block\" class=\"btn btn-primary\"> <i class=\"entypo-block\"></i></a>
                        {% else %}
                        <a href=\"{{ path('sub_admin_user_block_users',{id:item.id}) }}\" title=\"UnBlock\" class=\"btn btn-success\"> <i class=\"entypo-check\"></i></a>
                        {% endif %}
                        <a href=\"{{ path('sub_admins_users_update',{id:item.id}) }}\" title=\"Edit Profile\" class=\"btn btn-default\"> <i class=\"entypo-pencil\"></i></a>
                        <a href=\"{{ path('main_sub_admin_user_delete',{id:item.id}) }}\" title=\"Delete\" class=\"btn btn-danger\"> <i class=\"entypo-trash\"></i></a>
                    </td>
                </tr>
            {% endif %}
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>#}
{% endblock %}", "SubAdminBundle:Users:Users.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\SubadminBundle/Resources/views/Users/Users.html.twig");
    }
}
