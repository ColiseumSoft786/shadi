<?php

/* AdminBundle:Admin/Ocupation:ocupation.html.twig */
class __TwigTemplate_4b9ce3d3e28fe9da9faced6b6dc5358254c16a24846e5bbf0bbdac23d2002025 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Admin/Ocupation:ocupation.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca628fbad9957cdcdc25c526d0ead9fd78631a5589f1f6cfe913b79e226cf36f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca628fbad9957cdcdc25c526d0ead9fd78631a5589f1f6cfe913b79e226cf36f->enter($__internal_ca628fbad9957cdcdc25c526d0ead9fd78631a5589f1f6cfe913b79e226cf36f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Ocupation:ocupation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ca628fbad9957cdcdc25c526d0ead9fd78631a5589f1f6cfe913b79e226cf36f->leave($__internal_ca628fbad9957cdcdc25c526d0ead9fd78631a5589f1f6cfe913b79e226cf36f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_b7c6922b43e243bfffd129b844b739f44742ca98cbc66db29c67ff33dc2d5f13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7c6922b43e243bfffd129b844b739f44742ca98cbc66db29c67ff33dc2d5f13->enter($__internal_b7c6922b43e243bfffd129b844b739f44742ca98cbc66db29c67ff33dc2d5f13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4 style=\"padding: 10px 0px;\">Ocupation</h4> <span><a href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_ocupation_insert");
        echo "\" class=\"btn btn-info\">Add Ocupation</a></span>

    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Ocupation</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Ocupation"] ?? $this->getContext($context, "Ocupation")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 43
            echo "            <tr class=\"odd gradeX\">
                <td> &nbsp; ";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"";
            // line 46
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_ocupation_update", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>Ocupation</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_b7c6922b43e243bfffd129b844b739f44742ca98cbc66db29c67ff33dc2d5f13->leave($__internal_b7c6922b43e243bfffd129b844b739f44742ca98cbc66db29c67ff33dc2d5f13_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Ocupation:ocupation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 50,  95 => 46,  90 => 44,  87 => 43,  83 => 42,  69 => 31,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::admin.html.twig' %}

{% block body %}
    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4 style=\"padding: 10px 0px;\">Ocupation</h4> <span><a href=\"{{ path('admin_ocupation_insert') }}\" class=\"btn btn-info\">Add Ocupation</a></span>

    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Ocupation</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        {% for item in Ocupation %}
            <tr class=\"odd gradeX\">
                <td> &nbsp; {{ item.name }}</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"{{ path('admin_ocupation_update',{id:item.id}) }}\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>Ocupation</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "AdminBundle:Admin/Ocupation:ocupation.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Ocupation/ocupation.html.twig");
    }
}
