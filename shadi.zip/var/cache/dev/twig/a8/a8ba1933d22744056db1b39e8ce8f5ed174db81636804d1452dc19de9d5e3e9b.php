<?php

/* ::subadmin.html.twig */
class __TwigTemplate_13d01200831525e8708bea8ba0179c34a33a0d5811718483e7af708595d810d0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'users_active' => array($this, 'block_users_active'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2473f6c959069c1537a850ae328e5c13e34343ef7e7b7bcdf4031fac67d9e160 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2473f6c959069c1537a850ae328e5c13e34343ef7e7b7bcdf4031fac67d9e160->enter($__internal_2473f6c959069c1537a850ae328e5c13e34343ef7e7b7bcdf4031fac67d9e160_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::subadmin.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<meta http-equiv=\"content-type\" content=\"text/html;charset=UTF-8\"/><!-- /Added by HTTrack -->
<head>
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <meta name=\"description\" content=\"Neon Admin Panel\"/>
    <meta name=\"author\" content=\"Laborator.co\"/>
    <link rel=\"icon\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(""), "html", null, true);
        echo "assets/images/favicon.ico\">
    <title>Shadi Online | ";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css\" id=\"style-resource-1\">
    <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/font-icons/entypo/css/entypo.css\" id=\"style-resource-2\">
    <link rel=\"stylesheet\" href=\"http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic\" id=\"style-resource-3\">

    <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/font-icons/font-awesome/css/font-awesome.min.css\" id=\"style-resource-4\">
    <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/bootstrap.css\" id=\"style-resource-4\">
    <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-core.css\" id=\"style-resource-5\">
    <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-theme.css\" id=\"style-resource-6\">
    <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-forms.css\" id=\"style-resource-7\">
    <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/custom.css\" id=\"style-resource-8\">
    <link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/skins/purple.css\" id=\"style-resource-8\">
    <script src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-1.11.3.min.js\"></script>
    <script src=\"https://demo.neontheme.com/assets/js/ie8-responsive-file-warning.js\"></script><![endif]-->
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script> <![endif]-->


<body class=\"page-body page-fade\" data-url=\"https://demo.neontheme.com\">
<div class=\"page-container\">
    <div class=\"sidebar-menu\">
        <div class=\"sidebar-menu-inner\">
            <header class=\"logo-env\"> <!-- logo -->
                <div class=\"logo\"><a href=\"\" style=\"font-size: 25px;\"> Shadi Online </a></div> <!-- logo collapse icon -->
                <div class=\"sidebar-collapse\"><a href=\"#\" class=\"sidebar-collapse-icon\">
                        <!-- add class \"with-animation\" if you want sidebar to have animation during expanding/collapsing transition -->
                        <i class=\"entypo-menu\"></i> </a></div>
                <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
                <div class=\"sidebar-mobile-menu visible-xs\"><a href=\"#\" class=\"with-animation\">
                        <!-- add class \"with-animation\" to support animation --> <i class=\"entypo-menu\"></i> </a></div>
            </header>
            <ul id=\"main-menu\" class=\"main-menu\">
                <li class=\"\"><a href=\"";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_users");
        echo "\"><i class=\"entypo-gauge\"></i><span
                                class=\"title\">Dashboard</span></a>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"entypo-users\"></i><span class=\"title\">Matrimony Members</span></a>
                    <ul>
                        <li><a href=\"";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("subadmins_users_insert");
        echo "\"><span class=\"title\">Add Members</span></a></li>
                        <li><a href=\"";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_all_members");
        echo "\"><span class=\"title\">All Members</span></a></li>
                        <li><a href=\"";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_my_members");
        echo "\"><span class=\"title\">My Members</span></a></li>
                        <li><a href=\"";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_other_members");
        echo "\"><span class=\"title\">Other Admin Members</span></a></li>
                    </ul>
                </li>
                <li class=\"";
        // line 56
        $this->displayBlock('users_active', $context, $blocks);
        echo "\"><a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_logout");
        echo "\"><i class=\"entypo-logout\"></i><span class=\"title\">Sign Out</span></a></li>
            </ul>
        </div>
    </div>
    <div class=\"main-content\">
        <div class=\"row\"> <!-- Profile Info and Notifications -->
            <div class=\"col-md-6 col-sm-8 clearfix\">
                <h1>Admin Panel</h1>
            </div> <!-- Raw Links -->
            <div class=\"col-md-6 col-sm-4 clearfix hidden-xs\">
                <ul class=\"list-inline links-list pull-right\">
                    <li><a href=\"";
        // line 67
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_logout");
        echo "\">
                            Log Out <i class=\"entypo-logout right\"></i> </a></li>
                </ul>
            </div>
        </div>
        <hr/>
        <br/>
        ";
        // line 74
        $this->displayBlock('body', $context, $blocks);
        // line 76
        echo "

        <!-- Footer -->
        <footer class=\"main\">

            &copy; 2018 <strong>Shadi Online</strong> Admin Theme by <a href=\"https://coliseumsoft.com/\"
                                                                   target=\"_blank\">Coliseum Soft</a></footer>
    </div>
    <!-- TS153837851214942: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates -->
    <div id=\"chat\" class=\"fixed\" data-current-user=\"Art Ramadani\" data-order-by-status=\"1\" data-max-chat-history=\"25\">
        <div class=\"chat-inner\"><h2 class=\"chat-header\"><a href=\"#\" class=\"chat-close\"><i class=\"entypo-cancel\"></i></a>
                <i class=\"entypo-users\"></i>
                Chat
                <span class=\"badge badge-success is-hidden\">0</span></h2>
            <div class=\"chat-group\" id=\"group-1\"><strong>Favorites</strong> <a href=\"#\" id=\"sample-user-123\"
                                                                               data-conversation-history=\"#sample_history\"><span
                            class=\"user-status is-online\"></span> <em>Catherine J. Watkins</em></a> <a href=\"#\"><span
                            class=\"user-status is-online\"></span> <em>Nicholas R. Walker</em></a> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Susan J. Best</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Brandon S. Young</em></a> <a href=\"#\"><span
                            class=\"user-status is-idle\"></span> <em>Fernando G. Olson</em></a></div>
            <div class=\"chat-group\" id=\"group-2\"><strong>Work</strong> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Robert J. Garcia</em></a> <a href=\"#\"
                                                                                                    data-conversation-history=\"#sample_history_2\"><span
                            class=\"user-status is-offline\"></span> <em>Daniel A. Pena</em></a> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Rodrigo E. Lozano</em></a></div>
            <div class=\"chat-group\" id=\"group-3\"><strong>Social</strong> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Velma G. Pearson</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Margaret R. Dedmon</em></a> <a href=\"#\"><span
                            class=\"user-status is-online\"></span> <em>Kathleen M. Canales</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Tracy J. Rodriguez</em></a></div>
        </div> <!-- conversation template -->
        <div class=\"chat-conversation\">
            <div class=\"conversation-header\"><a href=\"#\" class=\"conversation-close\"><i class=\"entypo-cancel\"></i></a>
                <span class=\"user-status\"></span> <span class=\"display-name\"></span>
                <small></small>
            </div>
            <ul class=\"conversation-body\"></ul>
            <div class=\"chat-textarea\"><textarea class=\"form-control autogrow\"
                                                 placeholder=\"Type your message\"></textarea></div>
        </div>
    </div> <!-- Chat Histories -->
    <ul class=\"chat-history\" id=\"sample_history\">
        <li><span class=\"user\">Art Ramadani</span>
            <p>Are you here?</p> <span class=\"time\">09:00</span></li>
        <li class=\"opponent\"><span class=\"user\">Catherine J. Watkins</span>
            <p>This message is pre-queued.</p> <span class=\"time\">09:25</span></li>
        <li class=\"opponent\"><span class=\"user\">Catherine J. Watkins</span>
            <p>Whohoo!</p> <span class=\"time\">09:26</span></li>
        <li class=\"opponent unread\"><span class=\"user\">Catherine J. Watkins</span>
            <p>Do you like it?</p> <span class=\"time\">09:27</span></li>
    </ul> <!-- Chat Histories -->
    <ul class=\"chat-history\" id=\"sample_history_2\">
        <li class=\"opponent unread\"><span class=\"user\">Daniel A. Pena</span>
            <p>I am going out.</p> <span class=\"time\">08:21</span></li>
        <li class=\"opponent unread\"><span class=\"user\">Daniel A. Pena</span>
            <p>Call me when you see this message.</p> <span class=\"time\">08:27</span></li>
    </ul>
</div>
<!-- Sample Modal (Default skin) -->
<div class=\"modal fade\" id=\"sample-modal-dialog-1\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Default Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Sample Modal (Skin inverted) -->
<div class=\"modal invert fade\" id=\"sample-modal-dialog-2\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Inverted Skin Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Sample Modal (Skin gray) -->
<div class=\"modal gray fade\" id=\"sample-modal-dialog-3\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Gray Skin Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Imported styles on this page -->
<link rel=\"stylesheet\" href=\"";
        // line 187
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/datatables/datatables.css\" id=\"style-resource-1\">

<link rel=\"stylesheet\" href=\"";
        // line 189
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/select2/select2-bootstrap.css\" id=\"style-resource-2\">
<link rel=\"stylesheet\" href=\"";
        // line 190
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/select2/select2.css\" id=\"style-resource-3\">
<link rel=\"stylesheet\" href=\"";
        // line 191
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jvectormap/jquery-jvectormap-1.2.2.css\" id=\"style-resource-1\">
<link rel=\"stylesheet\" href=\"";
        // line 192
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/rickshaw/rickshaw.min.css\" id=\"style-resource-2\">
<script src=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/gsap/TweenMax.min.js\" id=\"script-resource-1\"></script>
<script src=\"";
        // line 194
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js\" id=\"script-resource-2\"></script>
<script src=\"";
        // line 195
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/bootstrap.js\" id=\"script-resource-3\"></script>
<script src=\"";
        // line 196
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/joinable.js\" id=\"script-resource-4\"></script>
<script src=\"";
        // line 197
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/resizeable.js\" id=\"script-resource-5\"></script>
<script src=\"";
        // line 198
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-api.js\" id=\"script-resource-6\"></script>
<script src=\"";
        // line 199
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/cookies.min.js\" id=\"script-resource-7\"></script>
<script src=\"";
        // line 200
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/bootstrap-switch.min.js\" id=\"script-resource-8\"></script>
<script src=\"";
        // line 201
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jvectormap/jquery-jvectormap-1.2.2.min.js\" id=\"script-resource-8\"></script>
<script src=\"";
        // line 202
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jvectormap/jquery-jvectormap-europe-merc-en.js\" id=\"script-resource-9\"></script>
<script src=\"";
        // line 203
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery.sparkline.min.js\" id=\"script-resource-10\"></script>
<script src=\"";
        // line 204
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/rickshaw/vendor/d3.v3.js\" id=\"script-resource-11\"></script>
<script src=\"";
        // line 205
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/rickshaw/rickshaw.min.js\" id=\"script-resource-12\"></script>
<script src=\"";
        // line 206
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/raphael-min.js\" id=\"script-resource-13\"></script>
<script src=\"";
        // line 207
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/morris.min.js\" id=\"script-resource-14\"></script>
<script src=\"";
        // line 208
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/toastr.js\" id=\"script-resource-15\"></script>
<script src=\"";
        // line 209
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-chat.js\" id=\"script-resource-16\"></script>

<script src=\"";
        // line 211
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/datatables/datatables.js\" id=\"script-resource-8\"></script>
<script src=\"";
        // line 212
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/select2/select2.min.js\" id=\"script-resource-9\"></script>
<!-- JavaScripts initializations and stuff -->
<script src=\"";
        // line 214
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-custom.js\" id=\"script-resource-17\"></script> <!-- Demo Settings -->
<script src=\"";
        // line 215
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-demo.js\" id=\"script-resource-18\"></script>
<script src=\"";
        // line 216
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-skins.js\" id=\"script-resource-19\"></script>
<script type=\"text/javascript\">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-28991003-7']);
    _gaq.push(['_setDomainName', 'demo.neontheme.com']);
    _gaq.push(['_trackPageview']);
    (function () {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();
</script>
</body>
</html>";
        
        $__internal_2473f6c959069c1537a850ae328e5c13e34343ef7e7b7bcdf4031fac67d9e160->leave($__internal_2473f6c959069c1537a850ae328e5c13e34343ef7e7b7bcdf4031fac67d9e160_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_3f80fc20df19c5556e4f1c12ba86552adfdc0dfaedc5ec8b5f5751f1059d2386 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f80fc20df19c5556e4f1c12ba86552adfdc0dfaedc5ec8b5f5751f1059d2386->enter($__internal_3f80fc20df19c5556e4f1c12ba86552adfdc0dfaedc5ec8b5f5751f1059d2386_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Panel";
        
        $__internal_3f80fc20df19c5556e4f1c12ba86552adfdc0dfaedc5ec8b5f5751f1059d2386->leave($__internal_3f80fc20df19c5556e4f1c12ba86552adfdc0dfaedc5ec8b5f5751f1059d2386_prof);

    }

    // line 56
    public function block_users_active($context, array $blocks = array())
    {
        $__internal_75e7bbb7111cba901fb12dba02197629631e954fe37dc11b68e7f3d9538ca479 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75e7bbb7111cba901fb12dba02197629631e954fe37dc11b68e7f3d9538ca479->enter($__internal_75e7bbb7111cba901fb12dba02197629631e954fe37dc11b68e7f3d9538ca479_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "users_active"));

        
        $__internal_75e7bbb7111cba901fb12dba02197629631e954fe37dc11b68e7f3d9538ca479->leave($__internal_75e7bbb7111cba901fb12dba02197629631e954fe37dc11b68e7f3d9538ca479_prof);

    }

    // line 74
    public function block_body($context, array $blocks = array())
    {
        $__internal_afc1ad67bfc5b05169f18bc80e4b884291dc85030977dd774c0b3bce91e52f19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_afc1ad67bfc5b05169f18bc80e4b884291dc85030977dd774c0b3bce91e52f19->enter($__internal_afc1ad67bfc5b05169f18bc80e4b884291dc85030977dd774c0b3bce91e52f19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 75
        echo "        ";
        
        $__internal_afc1ad67bfc5b05169f18bc80e4b884291dc85030977dd774c0b3bce91e52f19->leave($__internal_afc1ad67bfc5b05169f18bc80e4b884291dc85030977dd774c0b3bce91e52f19_prof);

    }

    public function getTemplateName()
    {
        return "::subadmin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  434 => 75,  428 => 74,  417 => 56,  405 => 12,  381 => 216,  377 => 215,  373 => 214,  368 => 212,  364 => 211,  359 => 209,  355 => 208,  351 => 207,  347 => 206,  343 => 205,  339 => 204,  335 => 203,  331 => 202,  327 => 201,  323 => 200,  319 => 199,  315 => 198,  311 => 197,  307 => 196,  303 => 195,  299 => 194,  295 => 193,  291 => 192,  287 => 191,  283 => 190,  279 => 189,  274 => 187,  161 => 76,  159 => 74,  149 => 67,  133 => 56,  127 => 53,  123 => 52,  119 => 51,  115 => 50,  106 => 44,  83 => 24,  79 => 23,  75 => 22,  71 => 21,  67 => 20,  63 => 19,  59 => 18,  55 => 17,  49 => 14,  45 => 13,  41 => 12,  37 => 11,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">

<meta http-equiv=\"content-type\" content=\"text/html;charset=UTF-8\"/><!-- /Added by HTTrack -->
<head>
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <meta name=\"description\" content=\"Neon Admin Panel\"/>
    <meta name=\"author\" content=\"Laborator.co\"/>
    <link rel=\"icon\" href=\"{{ asset('') }}assets/images/favicon.ico\">
    <title>Shadi Online | {% block title %}Panel{% endblock %}</title>
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css\" id=\"style-resource-1\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/font-icons/entypo/css/entypo.css\" id=\"style-resource-2\">
    <link rel=\"stylesheet\" href=\"http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic\" id=\"style-resource-3\">

    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/font-icons/font-awesome/css/font-awesome.min.css\" id=\"style-resource-4\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/bootstrap.css\" id=\"style-resource-4\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-core.css\" id=\"style-resource-5\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-theme.css\" id=\"style-resource-6\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-forms.css\" id=\"style-resource-7\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/custom.css\" id=\"style-resource-8\">
    <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/skins/purple.css\" id=\"style-resource-8\">
    <script src=\"{{ asset('bundles/') }}assets/js/jquery-1.11.3.min.js\"></script>
    <script src=\"https://demo.neontheme.com/assets/js/ie8-responsive-file-warning.js\"></script><![endif]-->
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script> <![endif]-->


<body class=\"page-body page-fade\" data-url=\"https://demo.neontheme.com\">
<div class=\"page-container\">
    <div class=\"sidebar-menu\">
        <div class=\"sidebar-menu-inner\">
            <header class=\"logo-env\"> <!-- logo -->
                <div class=\"logo\"><a href=\"\" style=\"font-size: 25px;\"> Shadi Online </a></div> <!-- logo collapse icon -->
                <div class=\"sidebar-collapse\"><a href=\"#\" class=\"sidebar-collapse-icon\">
                        <!-- add class \"with-animation\" if you want sidebar to have animation during expanding/collapsing transition -->
                        <i class=\"entypo-menu\"></i> </a></div>
                <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
                <div class=\"sidebar-mobile-menu visible-xs\"><a href=\"#\" class=\"with-animation\">
                        <!-- add class \"with-animation\" to support animation --> <i class=\"entypo-menu\"></i> </a></div>
            </header>
            <ul id=\"main-menu\" class=\"main-menu\">
                <li class=\"\"><a href=\"{{ path('sub_admins_users') }}\"><i class=\"entypo-gauge\"></i><span
                                class=\"title\">Dashboard</span></a>
                </li>

                <li class=\"has-sub\"><a href=\"\"><i class=\"entypo-users\"></i><span class=\"title\">Matrimony Members</span></a>
                    <ul>
                        <li><a href=\"{{ path('subadmins_users_insert') }}\"><span class=\"title\">Add Members</span></a></li>
                        <li><a href=\"{{ path('sub_admins_all_members') }}\"><span class=\"title\">All Members</span></a></li>
                        <li><a href=\"{{ path('sub_admins_my_members') }}\"><span class=\"title\">My Members</span></a></li>
                        <li><a href=\"{{ path('sub_admins_other_members') }}\"><span class=\"title\">Other Admin Members</span></a></li>
                    </ul>
                </li>
                <li class=\"{% block users_active %}{% endblock %}\"><a href=\"{{ path('sub_admins_logout') }}\"><i class=\"entypo-logout\"></i><span class=\"title\">Sign Out</span></a></li>
            </ul>
        </div>
    </div>
    <div class=\"main-content\">
        <div class=\"row\"> <!-- Profile Info and Notifications -->
            <div class=\"col-md-6 col-sm-8 clearfix\">
                <h1>Admin Panel</h1>
            </div> <!-- Raw Links -->
            <div class=\"col-md-6 col-sm-4 clearfix hidden-xs\">
                <ul class=\"list-inline links-list pull-right\">
                    <li><a href=\"{{ path('sub_admins_logout') }}\">
                            Log Out <i class=\"entypo-logout right\"></i> </a></li>
                </ul>
            </div>
        </div>
        <hr/>
        <br/>
        {% block body %}
        {% endblock %}


        <!-- Footer -->
        <footer class=\"main\">

            &copy; 2018 <strong>Shadi Online</strong> Admin Theme by <a href=\"https://coliseumsoft.com/\"
                                                                   target=\"_blank\">Coliseum Soft</a></footer>
    </div>
    <!-- TS153837851214942: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates -->
    <div id=\"chat\" class=\"fixed\" data-current-user=\"Art Ramadani\" data-order-by-status=\"1\" data-max-chat-history=\"25\">
        <div class=\"chat-inner\"><h2 class=\"chat-header\"><a href=\"#\" class=\"chat-close\"><i class=\"entypo-cancel\"></i></a>
                <i class=\"entypo-users\"></i>
                Chat
                <span class=\"badge badge-success is-hidden\">0</span></h2>
            <div class=\"chat-group\" id=\"group-1\"><strong>Favorites</strong> <a href=\"#\" id=\"sample-user-123\"
                                                                               data-conversation-history=\"#sample_history\"><span
                            class=\"user-status is-online\"></span> <em>Catherine J. Watkins</em></a> <a href=\"#\"><span
                            class=\"user-status is-online\"></span> <em>Nicholas R. Walker</em></a> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Susan J. Best</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Brandon S. Young</em></a> <a href=\"#\"><span
                            class=\"user-status is-idle\"></span> <em>Fernando G. Olson</em></a></div>
            <div class=\"chat-group\" id=\"group-2\"><strong>Work</strong> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Robert J. Garcia</em></a> <a href=\"#\"
                                                                                                    data-conversation-history=\"#sample_history_2\"><span
                            class=\"user-status is-offline\"></span> <em>Daniel A. Pena</em></a> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Rodrigo E. Lozano</em></a></div>
            <div class=\"chat-group\" id=\"group-3\"><strong>Social</strong> <a href=\"#\"><span
                            class=\"user-status is-busy\"></span> <em>Velma G. Pearson</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Margaret R. Dedmon</em></a> <a href=\"#\"><span
                            class=\"user-status is-online\"></span> <em>Kathleen M. Canales</em></a> <a href=\"#\"><span
                            class=\"user-status is-offline\"></span> <em>Tracy J. Rodriguez</em></a></div>
        </div> <!-- conversation template -->
        <div class=\"chat-conversation\">
            <div class=\"conversation-header\"><a href=\"#\" class=\"conversation-close\"><i class=\"entypo-cancel\"></i></a>
                <span class=\"user-status\"></span> <span class=\"display-name\"></span>
                <small></small>
            </div>
            <ul class=\"conversation-body\"></ul>
            <div class=\"chat-textarea\"><textarea class=\"form-control autogrow\"
                                                 placeholder=\"Type your message\"></textarea></div>
        </div>
    </div> <!-- Chat Histories -->
    <ul class=\"chat-history\" id=\"sample_history\">
        <li><span class=\"user\">Art Ramadani</span>
            <p>Are you here?</p> <span class=\"time\">09:00</span></li>
        <li class=\"opponent\"><span class=\"user\">Catherine J. Watkins</span>
            <p>This message is pre-queued.</p> <span class=\"time\">09:25</span></li>
        <li class=\"opponent\"><span class=\"user\">Catherine J. Watkins</span>
            <p>Whohoo!</p> <span class=\"time\">09:26</span></li>
        <li class=\"opponent unread\"><span class=\"user\">Catherine J. Watkins</span>
            <p>Do you like it?</p> <span class=\"time\">09:27</span></li>
    </ul> <!-- Chat Histories -->
    <ul class=\"chat-history\" id=\"sample_history_2\">
        <li class=\"opponent unread\"><span class=\"user\">Daniel A. Pena</span>
            <p>I am going out.</p> <span class=\"time\">08:21</span></li>
        <li class=\"opponent unread\"><span class=\"user\">Daniel A. Pena</span>
            <p>Call me when you see this message.</p> <span class=\"time\">08:27</span></li>
    </ul>
</div>
<!-- Sample Modal (Default skin) -->
<div class=\"modal fade\" id=\"sample-modal-dialog-1\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Default Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Sample Modal (Skin inverted) -->
<div class=\"modal invert fade\" id=\"sample-modal-dialog-2\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Inverted Skin Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Sample Modal (Skin gray) -->
<div class=\"modal gray fade\" id=\"sample-modal-dialog-3\">
    <div class=\"modal-dialog\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>
                <h4 class=\"modal-title\">Widget Options - Gray Skin Modal</h4></div>
            <div class=\"modal-body\"><p>Now residence dashwoods she excellent you. Shade being under his bed her. Much
                    read on as draw. Blessing for ignorant exercise any yourself unpacked. Pleasant horrible but
                    confined day end marriage. Eagerness furniture set preserved far recommend. Did even but nor are
                    most gave hope. Secure active living depend son repair day ladies now.</p></div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>
                <button type=\"button\" class=\"btn btn-primary\">Save changes</button>
            </div>
        </div>
    </div>
</div> <!-- Imported styles on this page -->
<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/datatables/datatables.css\" id=\"style-resource-1\">

<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/select2/select2-bootstrap.css\" id=\"style-resource-2\">
<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/select2/select2.css\" id=\"style-resource-3\">
<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/jvectormap/jquery-jvectormap-1.2.2.css\" id=\"style-resource-1\">
<link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/rickshaw/rickshaw.min.css\" id=\"style-resource-2\">
<script src=\"{{ asset('bundles/') }}assets/js/gsap/TweenMax.min.js\" id=\"script-resource-1\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js\" id=\"script-resource-2\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/bootstrap.js\" id=\"script-resource-3\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/joinable.js\" id=\"script-resource-4\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/resizeable.js\" id=\"script-resource-5\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/neon-api.js\" id=\"script-resource-6\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/cookies.min.js\" id=\"script-resource-7\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/bootstrap-switch.min.js\" id=\"script-resource-8\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/jvectormap/jquery-jvectormap-1.2.2.min.js\" id=\"script-resource-8\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/jvectormap/jquery-jvectormap-europe-merc-en.js\" id=\"script-resource-9\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/jquery.sparkline.min.js\" id=\"script-resource-10\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/rickshaw/vendor/d3.v3.js\" id=\"script-resource-11\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/rickshaw/rickshaw.min.js\" id=\"script-resource-12\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/raphael-min.js\" id=\"script-resource-13\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/morris.min.js\" id=\"script-resource-14\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/toastr.js\" id=\"script-resource-15\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/neon-chat.js\" id=\"script-resource-16\"></script>

<script src=\"{{ asset('bundles/') }}assets/js/datatables/datatables.js\" id=\"script-resource-8\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/select2/select2.min.js\" id=\"script-resource-9\"></script>
<!-- JavaScripts initializations and stuff -->
<script src=\"{{ asset('bundles/') }}assets/js/neon-custom.js\" id=\"script-resource-17\"></script> <!-- Demo Settings -->
<script src=\"{{ asset('bundles/') }}assets/js/neon-demo.js\" id=\"script-resource-18\"></script>
<script src=\"{{ asset('bundles/') }}assets/js/neon-skins.js\" id=\"script-resource-19\"></script>
<script type=\"text/javascript\">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-28991003-7']);
    _gaq.push(['_setDomainName', 'demo.neontheme.com']);
    _gaq.push(['_trackPageview']);
    (function () {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();
</script>
</body>
</html>", "::subadmin.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\app/Resources\\views/subadmin.html.twig");
    }
}
