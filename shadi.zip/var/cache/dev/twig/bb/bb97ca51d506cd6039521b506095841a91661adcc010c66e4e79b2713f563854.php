<?php

/* SubAdminBundle:Users:SAdminMyMembers.html.twig */
class __TwigTemplate_36d0150c73db53673a0cf109f04b16899a5804f03280ba26786605716731893b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::subadmin.html.twig", "SubAdminBundle:Users:SAdminMyMembers.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::subadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_116cd30ea651ccf2dbe2a062e1174f05996b3d138e71175ea34c51fb16c03506 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_116cd30ea651ccf2dbe2a062e1174f05996b3d138e71175ea34c51fb16c03506->enter($__internal_116cd30ea651ccf2dbe2a062e1174f05996b3d138e71175ea34c51fb16c03506_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SubAdminBundle:Users:SAdminMyMembers.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_116cd30ea651ccf2dbe2a062e1174f05996b3d138e71175ea34c51fb16c03506->leave($__internal_116cd30ea651ccf2dbe2a062e1174f05996b3d138e71175ea34c51fb16c03506_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_db7d672916039d6a2635b6bf1ba9c7e0c9736df6ff876aa07e2e9d97cb578519 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db7d672916039d6a2635b6bf1ba9c7e0c9736df6ff876aa07e2e9d97cb578519->enter($__internal_db7d672916039d6a2635b6bf1ba9c7e0c9736df6ff876aa07e2e9d97cb578519_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        // line 5
        echo "    <script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>
    ";
        // line 115
        echo "    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>

    <h4>My Members</h4>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 188
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["SAdminMyMembers"] ?? $this->getContext($context, "SAdminMyMembers")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 189
            echo "            ";
            if (($this->getAttribute($context["item"], "block", array()) != 2)) {
                // line 190
                echo "                <tr class=\"odd gradeX\" style=\"text-align: center;\">
                    <td> &nbsp; <img src=\"";
                // line 191
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($this->getAttribute($context["item"], "upic", array())), "html", null, true);
                echo "\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    <td style=\"vertical-align: middle;\">";
                // line 192
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "userid", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 193
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uname", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 194
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uphone", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 195
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "umartialstatus", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 196
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uage", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 197
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "country", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 198
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "state", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 199
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "city", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 200
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "religion", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 201
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "caste", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 202
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "startdate", array()), "html", null, true);
                echo "</td>
                    ";
                // line 203
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->controller("AdminBundle:Sidebar:AdminUserPackagePartialView", array("id" => $this->getAttribute(                // line 204
$context["item"], "id", array()))));
                // line 205
                echo "
                    <td class=\"col-md-3\" style=\"width: 30%; padding: 20px 0px; text-align: center;\">
                        <a style=\"margin-bottom: 5px;\" href=\"";
                // line 207
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_users_update", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Edit Profile\" class=\"btn btn-default\"> <i class=\"entypo-pencil\"></i></a>
                        <a style=\"margin-bottom: 5px;\" href=\"";
                // line 208
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_users_profile", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"View Profile\" class=\"btn btn-primary\"> <i class=\"entypo-eye\"></i></a>
                        ";
                // line 209
                if (($this->getAttribute($context["item"], "block", array()) == 0)) {
                    // line 210
                    echo "                            <a style=\"margin-bottom: 5px;\" href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admin_user_block", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                    echo "\" title=\"Block\" class=\"btn btn-danger\"><i class=\"entypo-block\"></i></a>
                        ";
                } else {
                    // line 212
                    echo "                            <a style=\"margin-bottom: 5px;\" href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admin_user_block", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                    echo "\" title=\"UnBlock\" class=\"btn btn-success\"><i class=\"fa fa-unlock\"></i></a>
                        ";
                }
                // line 214
                echo "                        <a style=\"margin-bottom: 5px;\" href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admin_user_delete", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Delete\" class=\"btn btn-danger\"><i class=\"entypo-trash\"></i></a>
                        <a style=\"margin-bottom: 5px;\" href=\"";
                // line 215
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_users_interest", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Send Interest\" class=\"btn btn-info\"><i class=\"entypo-heart\"></i></a>
                        <a style=\"margin-bottom: 5px;\" href=\"";
                // line 216
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("users_notification", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Notifications\" class=\"btn btn-primary\"><i class=\"entypo-bell\"></i></a>
                    </td>
                </tr>
            ";
            }
            // line 220
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 221
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_db7d672916039d6a2635b6bf1ba9c7e0c9736df6ff876aa07e2e9d97cb578519->leave($__internal_db7d672916039d6a2635b6bf1ba9c7e0c9736df6ff876aa07e2e9d97cb578519_prof);

    }

    public function getTemplateName()
    {
        return "SubAdminBundle:Users:SAdminMyMembers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  337 => 221,  331 => 220,  324 => 216,  320 => 215,  315 => 214,  309 => 212,  303 => 210,  301 => 209,  297 => 208,  293 => 207,  289 => 205,  287 => 204,  286 => 203,  282 => 202,  278 => 201,  274 => 200,  270 => 199,  266 => 198,  262 => 197,  258 => 196,  254 => 195,  250 => 194,  246 => 193,  242 => 192,  238 => 191,  235 => 190,  232 => 189,  228 => 188,  153 => 115,  42 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::subadmin.html.twig' %}

{% block body %}
    {#filtration scripts#}
    <script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>
    {#filtration scripts#}
    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>

    <h4>My Members</h4>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        {% for item in SAdminMyMembers %}
            {% if item.block != 2 %}
                <tr class=\"odd gradeX\" style=\"text-align: center;\">
                    <td> &nbsp; <img src=\"{{ asset(item.upic) }}\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    <td style=\"vertical-align: middle;\">{{ item.userid }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uname }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uphone }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.umartialstatus }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uage }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.country.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.state.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.city.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.religion.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.caste.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.startdate }}</td>
                    {{ render(controller(
                        'AdminBundle:Sidebar:AdminUserPackagePartialView',{'id':item.id}
                    )) }}
                    <td class=\"col-md-3\" style=\"width: 30%; padding: 20px 0px; text-align: center;\">
                        <a style=\"margin-bottom: 5px;\" href=\"{{ path('sub_admins_users_update',{id:item.id}) }}\" title=\"Edit Profile\" class=\"btn btn-default\"> <i class=\"entypo-pencil\"></i></a>
                        <a style=\"margin-bottom: 5px;\" href=\"{{ path('sub_admins_users_profile',{id:item.id}) }}\" title=\"View Profile\" class=\"btn btn-primary\"> <i class=\"entypo-eye\"></i></a>
                        {% if item.block == 0 %}
                            <a style=\"margin-bottom: 5px;\" href=\"{{ path('sub_admin_user_block',{id:item.id}) }}\" title=\"Block\" class=\"btn btn-danger\"><i class=\"entypo-block\"></i></a>
                        {% else %}
                            <a style=\"margin-bottom: 5px;\" href=\"{{ path('sub_admin_user_block',{id:item.id}) }}\" title=\"UnBlock\" class=\"btn btn-success\"><i class=\"fa fa-unlock\"></i></a>
                        {% endif %}
                        <a style=\"margin-bottom: 5px;\" href=\"{{ path('sub_admin_user_delete',{id:item.id}) }}\" title=\"Delete\" class=\"btn btn-danger\"><i class=\"entypo-trash\"></i></a>
                        <a style=\"margin-bottom: 5px;\" href=\"{{ path('sub_admins_users_interest',{id:item.id}) }}\" title=\"Send Interest\" class=\"btn btn-info\"><i class=\"entypo-heart\"></i></a>
                        <a style=\"margin-bottom: 5px;\" href=\"{{ path('users_notification',{id:item.id}) }}\" title=\"Notifications\" class=\"btn btn-primary\"><i class=\"entypo-bell\"></i></a>
                    </td>
                </tr>
            {% endif %}
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "SubAdminBundle:Users:SAdminMyMembers.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\SubadminBundle/Resources/views/Users/SAdminMyMembers.html.twig");
    }
}
