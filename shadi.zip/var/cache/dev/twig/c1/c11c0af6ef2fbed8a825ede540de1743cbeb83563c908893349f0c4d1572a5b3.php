<?php

/* AdminBundle:Admin/Sidebar:AllMembers.html.twig */
class __TwigTemplate_7233a841ca62805145220598573f9b718b538e51a4caf74bf991004e076d69f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Admin/Sidebar:AllMembers.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae210263ad0bdff86a01702414508334ee8e1c58293f11dd31fa5bf60df7b943 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae210263ad0bdff86a01702414508334ee8e1c58293f11dd31fa5bf60df7b943->enter($__internal_ae210263ad0bdff86a01702414508334ee8e1c58293f11dd31fa5bf60df7b943_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Sidebar:AllMembers.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ae210263ad0bdff86a01702414508334ee8e1c58293f11dd31fa5bf60df7b943->leave($__internal_ae210263ad0bdff86a01702414508334ee8e1c58293f11dd31fa5bf60df7b943_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_b2b29e88c8661c464c01686a097c71e3963f623e07d78310e2f3860fd4db3ad4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2b29e88c8661c464c01686a097c71e3963f623e07d78310e2f3860fd4db3ad4->enter($__internal_b2b29e88c8661c464c01686a097c71e3963f623e07d78310e2f3860fd4db3ad4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        // line 5
        echo "    <script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>
    ";
        // line 115
        echo "    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4>All Members</h4>

    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Picture</th>
            <th>Userid</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 194
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Users"] ?? $this->getContext($context, "Users")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 195
            echo "            ";
            if (($this->getAttribute($context["item"], "block", array()) != 2)) {
                // line 196
                echo "            <tr class=\"odd gradeX\" style=\"vertical-align: middle; text-align: center;\">
                ";
                // line 197
                if (($this->getAttribute($context["item"], "approve", array()) == 1)) {
                    // line 198
                    echo "                    <td> &nbsp; <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($this->getAttribute($context["item"], "upic", array())), "html", null, true);
                    echo "\" style=\"width: 60px; height: 60px;\" alt=\"\"></td>
                    ";
                } else {
                    // line 200
                    echo "                        <td> &nbsp; Pending </td>
                ";
                }
                // line 202
                echo "                <td style=\"vertical-align: middle;\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "userid", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 203
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uname", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 204
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uphone", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 205
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "umartialstatus", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 206
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uage", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 207
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "country", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 208
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "state", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 209
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "city", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 210
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "religion", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 211
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "caste", array()), "name", array()), "html", null, true);
                echo "</td>
                <td style=\"vertical-align: middle;\"> ";
                // line 212
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "startdate", array()), "html", null, true);
                echo "</td>
                ";
                // line 213
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->controller("AdminBundle:Sidebar:AdminUserPackagePartialView", array("id" => $this->getAttribute(                // line 214
$context["item"], "id", array()))));
                // line 215
                echo "
                <td class=\"col-md-2\" style=\" width: 30%;\">
                    <a href=\"";
                // line 217
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("Admin_sub_admins_users_update", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Edit Profile\" class=\"btn btn-default\"> <i class=\"entypo-pencil\"></i></a>
                    <a href=\"";
                // line 218
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admins_single_users_profile", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"View Profile\" class=\"btn btn-primary\"> <i class=\"entypo-eye\"></i></a>
                    ";
                // line 219
                if (($this->getAttribute($context["item"], "block", array()) == 0)) {
                    // line 220
                    echo "                        <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_sub_admin_user_block", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                    echo "\" title=\"Block\" class=\"btn btn-danger\"> <i class=\"entypo-block\"></i></a>
                        ";
                } else {
                    // line 222
                    echo "                        <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_sub_admin_user_block", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                    echo "\" title=\"UnBlock\" class=\"btn btn-success\"> <i class=\"entypo-check\"></i></a>
                    ";
                }
                // line 224
                echo "                    <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_sub_admin_user_delete", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Delete\" class=\"btn btn-danger\"> <i class=\"entypo-trash\"></i></a>
                    <a href=\"";
                // line 225
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_user_membership", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Membership\" class=\"btn btn-info\"> <i class=\"entypo-plus-circled\"></i></a>
                    ";
                // line 226
                if (($this->getAttribute($context["item"], "approve", array()) == 0)) {
                    // line 227
                    echo "                        <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admin_user_profile_approve", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                    echo "\" title=\"Pending\" class=\"btn btn-info\"> <i class=\"entypo-picasa\"></i></a>
                        ";
                } else {
                    // line 229
                    echo "                            <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admin_user_profile_approve", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                    echo "\" title=\"Approved\" class=\"btn btn-success\"> <i class=\"entypo-picture\"></i></a>
                    ";
                }
                // line 231
                echo "                </td>
            </tr>
            ";
            }
            // line 234
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 235
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>User ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_b2b29e88c8661c464c01686a097c71e3963f623e07d78310e2f3860fd4db3ad4->leave($__internal_b2b29e88c8661c464c01686a097c71e3963f623e07d78310e2f3860fd4db3ad4_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Sidebar:AllMembers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  364 => 235,  358 => 234,  353 => 231,  347 => 229,  341 => 227,  339 => 226,  335 => 225,  330 => 224,  324 => 222,  318 => 220,  316 => 219,  312 => 218,  308 => 217,  304 => 215,  302 => 214,  301 => 213,  297 => 212,  293 => 211,  289 => 210,  285 => 209,  281 => 208,  277 => 207,  273 => 206,  269 => 205,  265 => 204,  261 => 203,  256 => 202,  252 => 200,  246 => 198,  244 => 197,  241 => 196,  238 => 195,  234 => 194,  153 => 115,  42 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::admin.html.twig' %}

{% block body %}
    {#filtration scripts#}
    <script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>
    {#filtration scripts#}
    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4>All Members</h4>

    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Picture</th>
            <th>Userid</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        {% for item in Users %}
            {% if item.block != 2 %}
            <tr class=\"odd gradeX\" style=\"vertical-align: middle; text-align: center;\">
                {% if item.approve == 1 %}
                    <td> &nbsp; <img src=\"{{ asset(item.upic) }}\" style=\"width: 60px; height: 60px;\" alt=\"\"></td>
                    {% else %}
                        <td> &nbsp; Pending </td>
                {% endif %}
                <td style=\"vertical-align: middle;\"> {{ item.userid }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.uname }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.uphone }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.umartialstatus }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.uage }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.country.name }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.state.name }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.city.name }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.religion.name }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.caste.name }}</td>
                <td style=\"vertical-align: middle;\"> {{ item.startdate }}</td>
                {{ render(controller(
                    'AdminBundle:Sidebar:AdminUserPackagePartialView',{'id':item.id}
                )) }}
                <td class=\"col-md-2\" style=\" width: 30%;\">
                    <a href=\"{{ path('Admin_sub_admins_users_update',{id:item.id}) }}\" title=\"Edit Profile\" class=\"btn btn-default\"> <i class=\"entypo-pencil\"></i></a>
                    <a href=\"{{ path('admins_single_users_profile',{id:item.id}) }}\" title=\"View Profile\" class=\"btn btn-primary\"> <i class=\"entypo-eye\"></i></a>
                    {% if item.block == 0 %}
                        <a href=\"{{ path('admin_sub_admin_user_block',{id:item.id}) }}\" title=\"Block\" class=\"btn btn-danger\"> <i class=\"entypo-block\"></i></a>
                        {% else %}
                        <a href=\"{{ path('admin_sub_admin_user_block',{id:item.id}) }}\" title=\"UnBlock\" class=\"btn btn-success\"> <i class=\"entypo-check\"></i></a>
                    {% endif %}
                    <a href=\"{{ path('admin_sub_admin_user_delete',{id:item.id}) }}\" title=\"Delete\" class=\"btn btn-danger\"> <i class=\"entypo-trash\"></i></a>
                    <a href=\"{{ path('admin_user_membership',{id:item.id}) }}\" title=\"Membership\" class=\"btn btn-info\"> <i class=\"entypo-plus-circled\"></i></a>
                    {% if item.approve == 0 %}
                        <a href=\"{{ path('sub_admin_user_profile_approve',{id:item.id}) }}\" title=\"Pending\" class=\"btn btn-info\"> <i class=\"entypo-picasa\"></i></a>
                        {% else %}
                            <a href=\"{{ path('sub_admin_user_profile_approve',{id:item.id}) }}\" title=\"Approved\" class=\"btn btn-success\"> <i class=\"entypo-picture\"></i></a>
                    {% endif %}
                </td>
            </tr>
            {% endif %}
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>User ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "AdminBundle:Admin/Sidebar:AllMembers.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Sidebar/AllMembers.html.twig");
    }
}
