<?php

/* SubAdminBundle:Interest:Notification.html.twig */
class __TwigTemplate_87b52012654fdd9bd13d4e37d3dc464f51e79ee233552016bd651152c4566972 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::subadmin.html.twig", "SubAdminBundle:Interest:Notification.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::subadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c515a8ee0e02df92d97ceab5f93d8c6d0c7a7b1a530d4a78754713acac4bf664 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c515a8ee0e02df92d97ceab5f93d8c6d0c7a7b1a530d4a78754713acac4bf664->enter($__internal_c515a8ee0e02df92d97ceab5f93d8c6d0c7a7b1a530d4a78754713acac4bf664_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SubAdminBundle:Interest:Notification.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c515a8ee0e02df92d97ceab5f93d8c6d0c7a7b1a530d4a78754713acac4bf664->leave($__internal_c515a8ee0e02df92d97ceab5f93d8c6d0c7a7b1a530d4a78754713acac4bf664_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ecfa6b8bdbffc935ddd950260fd83ebf72930e39b7f883c23968f0c5b13e3488 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ecfa6b8bdbffc935ddd950260fd83ebf72930e39b7f883c23968f0c5b13e3488->enter($__internal_ecfa6b8bdbffc935ddd950260fd83ebf72930e39b7f883c23968f0c5b13e3488_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<h2>Interest Notifications</h2> <br/>
<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"panel panel-primary\" data-collapsed=\"0\">
            <div class=\"panel-heading\">
                <div class=\"panel-title\">
                    Interests
                </div>
                <div class=\"panel-options\"> <a href=\"#\" data-rel=\"collapse\"><i
                                class=\"entypo-down-open\"></i></a> <a href=\"#\" data-rel=\"reload\"><i
                                class=\"entypo-arrows-ccw\"></i></a> <a href=\"#\" data-rel=\"close\"><i
                                class=\"entypo-cancel\"></i></a></div>
            </div>
            <div class=\"panel-body\">

                <div class=\"col-md-6\">
                    <h3>Interest Received</h3>
                    <div class=\"col-md-10\" style=\"padding: 15px 0px;\">
                            <table class=\"table table-striped\">
                                <thead>
                                <tr>
                                    <th style=\"text-align: center;\">UserId</th>
                                    <th style=\"text-align: center;\">Name</th>
                                    <th style=\"text-align: center;\">Date</th>
                                    <th style=\"text-align: center;\">Status</th>
                                    <th style=\"text-align: center;\">Profile</th>
                                </tr>
                                </thead>
                                <tbody>
                                ";
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Sendby"] ?? $this->getContext($context, "Sendby")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 35
            echo "                                    <tr style=\"text-align: center;\">
                                    <td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "sendto", array()), "userid", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "sendto", array()), "uname", array()), "html", null, true);
            echo "</td>
                                    <td>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "date", array()), "html", null, true);
            echo "</td>
                                    ";
            // line 39
            if (($this->getAttribute($context["item"], "accept", array()) == 1)) {
                // line 40
                echo "                                        <td><a href=\"javascript:void(0);\" class=\"btn btn-success\">Accepted</a></td>
                                    ";
            } elseif (($this->getAttribute(            // line 41
$context["item"], "accept", array()) == 2)) {
                // line 42
                echo "                                        <td><a href=\"javascript:void(0);\" class=\"btn btn-danger\">Rejected</a></td>
                                    ";
            } else {
                // line 44
                echo "                                        <td><a href=\"javascript:void(0);\" class=\"btn btn-info\">Pending</a></td>
                                    ";
            }
            // line 46
            echo "                                        <td><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("single_users_interest_profile", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\">View Profile</a></td>
                                    </tr>

                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "                                </tbody>
                            </table>
                    </div>
                </div>

                <div class=\"col-md-6\">
                    <h3>Interest Sent</h3>
                    <div class=\"col-md-10\" style=\"padding: 15px 0px;\">
                        <table class=\"table table-striped\">
                            <thead>
                            <tr>
                                <th style=\"text-align: center;\">User ID</th>
                                <th style=\"text-align: center;\">Name</th>
                                <th style=\"text-align: center;\">Phone</th>
                                <th style=\"text-align: center;\">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            ";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Sendto"] ?? $this->getContext($context, "Sendto")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 69
            echo "                                <tr style=\"text-align: center;\">
                                    ";
            // line 70
            if (($this->getAttribute($context["item"], "accept", array()) == 0)) {
                // line 71
                echo "                                        <td>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "sendby", array()), "userid", array()), "html", null, true);
                echo "</td>
                                        <td>";
                // line 72
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "sendby", array()), "uname", array()), "html", null, true);
                echo "</td>
                                        <td>Pending</td>
                                        <td><a href=\"javascript:void(0)\" class=\"btn btn-info\">Pending</a></td>
                                    ";
            } elseif (($this->getAttribute(            // line 75
$context["item"], "accept", array()) == 1)) {
                // line 76
                echo "                                        <td>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "sendby", array()), "userid", array()), "html", null, true);
                echo "</td>
                                        <td>";
                // line 77
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "sendby", array()), "uname", array()), "html", null, true);
                echo "</td>
                                        <td>";
                // line 78
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "sendby", array()), "uphone", array()), "html", null, true);
                echo "</td>
                                        <td><a href=\"javascript:void(0)\" class=\"btn btn-success\">Accepted</a></td>
                                    ";
            } elseif (($this->getAttribute(            // line 80
$context["item"], "accept", array()) == 2)) {
                // line 81
                echo "                                        <td>Expired</td>
                                        <td><a href=\"javascript:void(0)\" class=\"btn btn-danger\">Rejected</a></td>
                                    ";
            }
            // line 84
            echo "                                    ";
            // line 85
            echo "                                </tr>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 87
        echo "                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
    <br><br><br><br><br>
    <br><br><br><br><br>

";
        
        $__internal_ecfa6b8bdbffc935ddd950260fd83ebf72930e39b7f883c23968f0c5b13e3488->leave($__internal_ecfa6b8bdbffc935ddd950260fd83ebf72930e39b7f883c23968f0c5b13e3488_prof);

    }

    public function getTemplateName()
    {
        return "SubAdminBundle:Interest:Notification.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  189 => 87,  182 => 85,  180 => 84,  175 => 81,  173 => 80,  168 => 78,  164 => 77,  159 => 76,  157 => 75,  151 => 72,  146 => 71,  144 => 70,  141 => 69,  137 => 68,  117 => 50,  106 => 46,  102 => 44,  98 => 42,  96 => 41,  93 => 40,  91 => 39,  87 => 38,  83 => 37,  79 => 36,  76 => 35,  72 => 34,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::subadmin.html.twig' %}

{% block body %}

<h2>Interest Notifications</h2> <br/>
<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"panel panel-primary\" data-collapsed=\"0\">
            <div class=\"panel-heading\">
                <div class=\"panel-title\">
                    Interests
                </div>
                <div class=\"panel-options\"> <a href=\"#\" data-rel=\"collapse\"><i
                                class=\"entypo-down-open\"></i></a> <a href=\"#\" data-rel=\"reload\"><i
                                class=\"entypo-arrows-ccw\"></i></a> <a href=\"#\" data-rel=\"close\"><i
                                class=\"entypo-cancel\"></i></a></div>
            </div>
            <div class=\"panel-body\">

                <div class=\"col-md-6\">
                    <h3>Interest Received</h3>
                    <div class=\"col-md-10\" style=\"padding: 15px 0px;\">
                            <table class=\"table table-striped\">
                                <thead>
                                <tr>
                                    <th style=\"text-align: center;\">UserId</th>
                                    <th style=\"text-align: center;\">Name</th>
                                    <th style=\"text-align: center;\">Date</th>
                                    <th style=\"text-align: center;\">Status</th>
                                    <th style=\"text-align: center;\">Profile</th>
                                </tr>
                                </thead>
                                <tbody>
                                {% for item in Sendby %}
                                    <tr style=\"text-align: center;\">
                                    <td>{{ item.sendto.userid }}</td>
                                    <td>{{ item.sendto.uname }}</td>
                                    <td>{{ item.date }}</td>
                                    {% if item.accept == 1 %}
                                        <td><a href=\"javascript:void(0);\" class=\"btn btn-success\">Accepted</a></td>
                                    {% elseif item.accept == 2 %}
                                        <td><a href=\"javascript:void(0);\" class=\"btn btn-danger\">Rejected</a></td>
                                    {% else %}
                                        <td><a href=\"javascript:void(0);\" class=\"btn btn-info\">Pending</a></td>
                                    {% endif %}
                                        <td><a href=\"{{ path('single_users_interest_profile',{id:item.id}) }}\" class=\"btn btn-primary\">View Profile</a></td>
                                    </tr>

                                {% endfor %}
                                </tbody>
                            </table>
                    </div>
                </div>

                <div class=\"col-md-6\">
                    <h3>Interest Sent</h3>
                    <div class=\"col-md-10\" style=\"padding: 15px 0px;\">
                        <table class=\"table table-striped\">
                            <thead>
                            <tr>
                                <th style=\"text-align: center;\">User ID</th>
                                <th style=\"text-align: center;\">Name</th>
                                <th style=\"text-align: center;\">Phone</th>
                                <th style=\"text-align: center;\">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            {% for item in Sendto %}
                                <tr style=\"text-align: center;\">
                                    {% if item.accept == 0 %}
                                        <td>{{ item.sendby.userid }}</td>
                                        <td>{{ item.sendby.uname }}</td>
                                        <td>Pending</td>
                                        <td><a href=\"javascript:void(0)\" class=\"btn btn-info\">Pending</a></td>
                                    {% elseif item.accept == 1 %}
                                        <td>{{ item.sendby.userid }}</td>
                                        <td>{{ item.sendby.uname }}</td>
                                        <td>{{ item.sendby.uphone }}</td>
                                        <td><a href=\"javascript:void(0)\" class=\"btn btn-success\">Accepted</a></td>
                                    {% elseif item.accept == 2 %}
                                        <td>Expired</td>
                                        <td><a href=\"javascript:void(0)\" class=\"btn btn-danger\">Rejected</a></td>
                                    {% endif %}
                                    {#<td><a href=\"{{ path('single_users_interest_profile',{id:item.id}) }}\" class=\"btn btn-primary\">View Profile</a></td>#}
                                </tr>
                            {% endfor %}
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
    <br><br><br><br><br>
    <br><br><br><br><br>

{% endblock %}", "SubAdminBundle:Interest:Notification.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\SubadminBundle/Resources/views/Interest/Notification.html.twig");
    }
}
