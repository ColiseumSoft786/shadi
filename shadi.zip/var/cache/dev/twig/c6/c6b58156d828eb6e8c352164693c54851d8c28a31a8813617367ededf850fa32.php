<?php

/* AdminBundle:Default:SAdminLogin.html.twig */
class __TwigTemplate_a7644ed616c6e99838a53889638b6cc178e80deda49badd2f240fa083c32e6ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_89ab062f202a724de0f4846a953cd98635d130246e1448f517d692e4a7c288d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89ab062f202a724de0f4846a953cd98635d130246e1448f517d692e4a7c288d2->enter($__internal_89ab062f202a724de0f4846a953cd98635d130246e1448f517d692e4a7c288d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Default:SAdminLogin.html.twig"));

        // line 1
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_89ab062f202a724de0f4846a953cd98635d130246e1448f517d692e4a7c288d2->leave($__internal_89ab062f202a724de0f4846a953cd98635d130246e1448f517d692e4a7c288d2_prof);

    }

    public function block_body($context, array $blocks = array())
    {
        $__internal_df185a0907c6fc8ff961ede39d354d642db496e18571e139cb0c310102ba538d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df185a0907c6fc8ff961ede39d354d642db496e18571e139cb0c310102ba538d->enter($__internal_df185a0907c6fc8ff961ede39d354d642db496e18571e139cb0c310102ba538d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 2
        echo "    <!DOCTYPE html>
    <html lang=\"en\">
    <meta http-equiv=\"content-type\" content=\"text/html;charset=UTF-8\"/>
    <head>
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <meta name=\"description\" content=\"Neon Admin Panel\"/>
        <meta name=\"author\" content=\"Laborator.co\"/>
        <link rel=\"icon\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/images/favicon.ico\">
        <title>Login</title>
        <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css\"
              id=\"style-resource-1\">
        <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/font-icons/entypo/css/entypo.css\" id=\"style-resource-2\">
        <link rel=\"stylesheet\" href=\"http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic\"
              id=\"style-resource-3\">
        <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/bootstrap.css\" id=\"style-resource-4\">
        <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-core.css\" id=\"style-resource-5\">
        <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-theme.css\" id=\"style-resource-6\">
        <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/neon-forms.css\" id=\"style-resource-7\">
        <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/css/custom.css\" id=\"style-resource-8\">
        <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-1.11.3.min.js\"></script>
        <!--[if lt IE 9]>
        <script src=\"https://demo.neontheme.com/assets/js/ie8-responsive-file-warning.js\"></script><![endif]-->
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries --> <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
        <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script> <![endif]-->
        <!-- TS1538378540: Neon - Responsive Admin Template created by Laborator --> </head>
    <body class=\"page-body login-page login-form-fall\" data-url=\"https://demo.neontheme.com\">
    <!-- TS153837854011138: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates -->
    <script type=\"text/javascript\">
        var baseurl = '../../index.html';
    </script>
    <div class=\"login-container\">
        <div class=\"login-header login-caret\">
            <div class=\"login-content\"><a href=\"#\" class=\"logo\" style=\"font-size: 35px;\"> Super Admin Panel </a>
                <p class=\"description\">Dear user, log in to access the admin area!</p> <!-- progress bar indicator -->
            </div>
        </div>
        <div class=\"login-progressbar\">
            <div></div>
        </div>
        <div class=\"login-form\">
            <div class=\"login-content\">
                <div class=\"form-login-error\"><h3>Invalid login</h3>
                    <p>Enter <strong>demo</strong>/<strong>demo</strong> as login and password.</p></div>
                <h4 style=\"color: #fff; padding-bottom: 3px;\">";
        // line 48
        echo twig_escape_filter($this->env, ($context["NotMatch"] ?? $this->getContext($context, "NotMatch")), "html", null, true);
        echo "</h4>
                <form action=\"\" method=\"post\" role=\"form\" >
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            <div class=\"input-group-addon\"><i class=\"entypo-user\"></i></div>
                            <input type=\"text\" class=\"form-control\" name=\"username\" id=\"username\" placeholder=\"Username\"
                                   autocomplete=\"off\"/></div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            <div class=\"input-group-addon\"><i class=\"entypo-key\"></i></div>
                            <input type=\"password\" class=\"form-control\" name=\"password\" id=\"password\" placeholder=\"Password\"
                                   autocomplete=\"off\"/></div>
                    </div>
                    <div class=\"form-group\">
                        <button type=\"submit\" class=\"btn btn-primary btn-block btn-login\"><i class=\"entypo-login\"></i>
                            Login In
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src=\"";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/gsap/TweenMax.min.js\" id=\"script-resource-1\"></script>
    <script src=\"";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js\" id=\"script-resource-2\"></script>
    <script src=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/bootstrap.js\" id=\"script-resource-3\"></script>
    <script src=\"";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/joinable.js\" id=\"script-resource-4\"></script>
    <script src=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/resizeable.js\" id=\"script-resource-5\"></script>
    <script src=\"";
        // line 76
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-api.js\" id=\"script-resource-6\"></script>
    <script src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/cookies.min.js\" id=\"script-resource-7\"></script>
    <script src=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/jquery.validate.min.js\" id=\"script-resource-8\"></script>
    <script src=\"";
        // line 79
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-login.js\" id=\"script-resource-9\"></script>
    <!-- JavaScripts initializations and stuff -->
    <script src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-custom.js\" id=\"script-resource-10\"></script> <!-- Demo Settings -->
    <script src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-demo.js\" id=\"script-resource-11\"></script>
    <script src=\"";
        // line 83
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/"), "html", null, true);
        echo "assets/js/neon-skins.js\" id=\"script-resource-12\"></script>
    <script type=\"text/javascript\">
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-28991003-7']);
        _gaq.push(['_setDomainName', 'demo.neontheme.com']);
        _gaq.push(['_trackPageview']);
        (function () {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
    </script>
    </body>
    </html>

";
        
        $__internal_df185a0907c6fc8ff961ede39d354d642db496e18571e139cb0c310102ba538d->leave($__internal_df185a0907c6fc8ff961ede39d354d642db496e18571e139cb0c310102ba538d_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Default:SAdminLogin.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  181 => 83,  177 => 82,  173 => 81,  168 => 79,  164 => 78,  160 => 77,  156 => 76,  152 => 75,  148 => 74,  144 => 73,  140 => 72,  136 => 71,  110 => 48,  82 => 23,  78 => 22,  74 => 21,  70 => 20,  66 => 19,  62 => 18,  56 => 15,  51 => 13,  46 => 11,  35 => 2,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block body %}
    <!DOCTYPE html>
    <html lang=\"en\">
    <meta http-equiv=\"content-type\" content=\"text/html;charset=UTF-8\"/>
    <head>
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <meta name=\"description\" content=\"Neon Admin Panel\"/>
        <meta name=\"author\" content=\"Laborator.co\"/>
        <link rel=\"icon\" href=\"{{ asset('bundles/') }}assets/images/favicon.ico\">
        <title>Login</title>
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css\"
              id=\"style-resource-1\">
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/font-icons/entypo/css/entypo.css\" id=\"style-resource-2\">
        <link rel=\"stylesheet\" href=\"http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic\"
              id=\"style-resource-3\">
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/bootstrap.css\" id=\"style-resource-4\">
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-core.css\" id=\"style-resource-5\">
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-theme.css\" id=\"style-resource-6\">
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/neon-forms.css\" id=\"style-resource-7\">
        <link rel=\"stylesheet\" href=\"{{ asset('bundles/') }}assets/css/custom.css\" id=\"style-resource-8\">
        <script src=\"{{ asset('bundles/') }}assets/js/jquery-1.11.3.min.js\"></script>
        <!--[if lt IE 9]>
        <script src=\"https://demo.neontheme.com/assets/js/ie8-responsive-file-warning.js\"></script><![endif]-->
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries --> <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
        <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script> <![endif]-->
        <!-- TS1538378540: Neon - Responsive Admin Template created by Laborator --> </head>
    <body class=\"page-body login-page login-form-fall\" data-url=\"https://demo.neontheme.com\">
    <!-- TS153837854011138: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates -->
    <script type=\"text/javascript\">
        var baseurl = '../../index.html';
    </script>
    <div class=\"login-container\">
        <div class=\"login-header login-caret\">
            <div class=\"login-content\"><a href=\"#\" class=\"logo\" style=\"font-size: 35px;\"> Super Admin Panel </a>
                <p class=\"description\">Dear user, log in to access the admin area!</p> <!-- progress bar indicator -->
            </div>
        </div>
        <div class=\"login-progressbar\">
            <div></div>
        </div>
        <div class=\"login-form\">
            <div class=\"login-content\">
                <div class=\"form-login-error\"><h3>Invalid login</h3>
                    <p>Enter <strong>demo</strong>/<strong>demo</strong> as login and password.</p></div>
                <h4 style=\"color: #fff; padding-bottom: 3px;\">{{ NotMatch }}</h4>
                <form action=\"\" method=\"post\" role=\"form\" >
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            <div class=\"input-group-addon\"><i class=\"entypo-user\"></i></div>
                            <input type=\"text\" class=\"form-control\" name=\"username\" id=\"username\" placeholder=\"Username\"
                                   autocomplete=\"off\"/></div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"input-group\">
                            <div class=\"input-group-addon\"><i class=\"entypo-key\"></i></div>
                            <input type=\"password\" class=\"form-control\" name=\"password\" id=\"password\" placeholder=\"Password\"
                                   autocomplete=\"off\"/></div>
                    </div>
                    <div class=\"form-group\">
                        <button type=\"submit\" class=\"btn btn-primary btn-block btn-login\"><i class=\"entypo-login\"></i>
                            Login In
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src=\"{{ asset('bundles/') }}assets/js/gsap/TweenMax.min.js\" id=\"script-resource-1\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js\" id=\"script-resource-2\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/bootstrap.js\" id=\"script-resource-3\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/joinable.js\" id=\"script-resource-4\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/resizeable.js\" id=\"script-resource-5\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/neon-api.js\" id=\"script-resource-6\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/cookies.min.js\" id=\"script-resource-7\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/jquery.validate.min.js\" id=\"script-resource-8\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/neon-login.js\" id=\"script-resource-9\"></script>
    <!-- JavaScripts initializations and stuff -->
    <script src=\"{{ asset('bundles/') }}assets/js/neon-custom.js\" id=\"script-resource-10\"></script> <!-- Demo Settings -->
    <script src=\"{{ asset('bundles/') }}assets/js/neon-demo.js\" id=\"script-resource-11\"></script>
    <script src=\"{{ asset('bundles/') }}assets/js/neon-skins.js\" id=\"script-resource-12\"></script>
    <script type=\"text/javascript\">
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-28991003-7']);
        _gaq.push(['_setDomainName', 'demo.neontheme.com']);
        _gaq.push(['_trackPageview']);
        (function () {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
    </script>
    </body>
    </html>

{% endblock %}", "AdminBundle:Default:SAdminLogin.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Default/SAdminLogin.html.twig");
    }
}
