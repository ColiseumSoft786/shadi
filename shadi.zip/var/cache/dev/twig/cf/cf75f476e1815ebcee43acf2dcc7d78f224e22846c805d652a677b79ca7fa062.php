<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_a179712f780cbd3d554f99f65ac985fdbfbd7be7e49dd93b77298d37e8fef3b8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b516ada45de625fd8be2fcd59a3f453f3062e13119e303d905cdd2ef53e4838 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b516ada45de625fd8be2fcd59a3f453f3062e13119e303d905cdd2ef53e4838->enter($__internal_6b516ada45de625fd8be2fcd59a3f453f3062e13119e303d905cdd2ef53e4838_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6b516ada45de625fd8be2fcd59a3f453f3062e13119e303d905cdd2ef53e4838->leave($__internal_6b516ada45de625fd8be2fcd59a3f453f3062e13119e303d905cdd2ef53e4838_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c7b19a6db9e794e00439fbdc4d43aca2021c37d9b20a7a1ec4b8c6d95b3b1d61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7b19a6db9e794e00439fbdc4d43aca2021c37d9b20a7a1ec4b8c6d95b3b1d61->enter($__internal_c7b19a6db9e794e00439fbdc4d43aca2021c37d9b20a7a1ec4b8c6d95b3b1d61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_c7b19a6db9e794e00439fbdc4d43aca2021c37d9b20a7a1ec4b8c6d95b3b1d61->leave($__internal_c7b19a6db9e794e00439fbdc4d43aca2021c37d9b20a7a1ec4b8c6d95b3b1d61_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_d7e3f9de6f455586e4f78aec7515350ed01632e07c882e2f0dff75b108f05204 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7e3f9de6f455586e4f78aec7515350ed01632e07c882e2f0dff75b108f05204->enter($__internal_d7e3f9de6f455586e4f78aec7515350ed01632e07c882e2f0dff75b108f05204_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_d7e3f9de6f455586e4f78aec7515350ed01632e07c882e2f0dff75b108f05204->leave($__internal_d7e3f9de6f455586e4f78aec7515350ed01632e07c882e2f0dff75b108f05204_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_e982b95e18f318b30349eb7420fa0f954c89b79a62f9cadc5e6f3d35499e2458 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e982b95e18f318b30349eb7420fa0f954c89b79a62f9cadc5e6f3d35499e2458->enter($__internal_e982b95e18f318b30349eb7420fa0f954c89b79a62f9cadc5e6f3d35499e2458_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_e982b95e18f318b30349eb7420fa0f954c89b79a62f9cadc5e6f3d35499e2458->leave($__internal_e982b95e18f318b30349eb7420fa0f954c89b79a62f9cadc5e6f3d35499e2458_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
