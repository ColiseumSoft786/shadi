<?php

/* AdminBundle:Admin/Education:education.html.twig */
class __TwigTemplate_96dd94552ec2d684b185e72ad825669ec55ccf8be7d52335c28fd8207192aad9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Admin/Education:education.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e65faf32f3a033d127f6960c3e3e6dc54ddb9d99b2c1b0249d272fec15c874e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e65faf32f3a033d127f6960c3e3e6dc54ddb9d99b2c1b0249d272fec15c874e6->enter($__internal_e65faf32f3a033d127f6960c3e3e6dc54ddb9d99b2c1b0249d272fec15c874e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Education:education.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e65faf32f3a033d127f6960c3e3e6dc54ddb9d99b2c1b0249d272fec15c874e6->leave($__internal_e65faf32f3a033d127f6960c3e3e6dc54ddb9d99b2c1b0249d272fec15c874e6_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_b0cbb143f01778ebbe5301a3be4a3995598226c85af2f6f7f88fead99f085fc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0cbb143f01778ebbe5301a3be4a3995598226c85af2f6f7f88fead99f085fc5->enter($__internal_b0cbb143f01778ebbe5301a3be4a3995598226c85af2f6f7f88fead99f085fc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4 style=\"padding: 10px 0px;\">Education</h4> <span><a href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_education_insert");
        echo "\" class=\"btn btn-info\">Add Education</a></span>

    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Education</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Education"] ?? $this->getContext($context, "Education")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 43
            echo "            <tr class=\"odd gradeX\">
                <td> &nbsp; ";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"";
            // line 46
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_education_update", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>Education</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_b0cbb143f01778ebbe5301a3be4a3995598226c85af2f6f7f88fead99f085fc5->leave($__internal_b0cbb143f01778ebbe5301a3be4a3995598226c85af2f6f7f88fead99f085fc5_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Education:education.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 50,  95 => 46,  90 => 44,  87 => 43,  83 => 42,  69 => 31,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::admin.html.twig' %}

{% block body %}
    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4 style=\"padding: 10px 0px;\">Education</h4> <span><a href=\"{{ path('admin_education_insert') }}\" class=\"btn btn-info\">Add Education</a></span>

    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Education</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        {% for item in Education %}
            <tr class=\"odd gradeX\">
                <td> &nbsp; {{ item.name }}</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"{{ path('admin_education_update',{id:item.id}) }}\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>Education</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "AdminBundle:Admin/Education:education.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Education/education.html.twig");
    }
}
