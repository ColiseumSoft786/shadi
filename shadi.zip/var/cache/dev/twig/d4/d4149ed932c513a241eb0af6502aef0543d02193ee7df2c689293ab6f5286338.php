<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_0d42f2e95edaec126aed945b5f4251a284bd9d8c36b1dae74965e797c89b569a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b5d6c0cf312993b7abb3659a191978a694577e9da8d43d8a25f5c17a7ad8431 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b5d6c0cf312993b7abb3659a191978a694577e9da8d43d8a25f5c17a7ad8431->enter($__internal_4b5d6c0cf312993b7abb3659a191978a694577e9da8d43d8a25f5c17a7ad8431_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4b5d6c0cf312993b7abb3659a191978a694577e9da8d43d8a25f5c17a7ad8431->leave($__internal_4b5d6c0cf312993b7abb3659a191978a694577e9da8d43d8a25f5c17a7ad8431_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_7e00cec12777bc58366ea59a471230a524368bd3f37a6eeef0b763cf2a177704 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e00cec12777bc58366ea59a471230a524368bd3f37a6eeef0b763cf2a177704->enter($__internal_7e00cec12777bc58366ea59a471230a524368bd3f37a6eeef0b763cf2a177704_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_7e00cec12777bc58366ea59a471230a524368bd3f37a6eeef0b763cf2a177704->leave($__internal_7e00cec12777bc58366ea59a471230a524368bd3f37a6eeef0b763cf2a177704_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_65f0e49004369539a7c5dfc826338bf2ebfd4b3521064608f102f374f25f21b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65f0e49004369539a7c5dfc826338bf2ebfd4b3521064608f102f374f25f21b2->enter($__internal_65f0e49004369539a7c5dfc826338bf2ebfd4b3521064608f102f374f25f21b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_65f0e49004369539a7c5dfc826338bf2ebfd4b3521064608f102f374f25f21b2->leave($__internal_65f0e49004369539a7c5dfc826338bf2ebfd4b3521064608f102f374f25f21b2_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_f4b48cb3787317a352925399e2d66b520adb476366d9a66a609923212894d9c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4b48cb3787317a352925399e2d66b520adb476366d9a66a609923212894d9c3->enter($__internal_f4b48cb3787317a352925399e2d66b520adb476366d9a66a609923212894d9c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_f4b48cb3787317a352925399e2d66b520adb476366d9a66a609923212894d9c3->leave($__internal_f4b48cb3787317a352925399e2d66b520adb476366d9a66a609923212894d9c3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}
