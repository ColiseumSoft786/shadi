<?php

/* SubAdminBundle:Users:SAdminAllMembers.html.twig */
class __TwigTemplate_7032c9af232b22f5c7381e7bba0c3b10f842e23eac90f734c10575e6bdf4636d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::subadmin.html.twig", "SubAdminBundle:Users:SAdminAllMembers.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::subadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2ef89b28fd9e9fd45dbc35030e22c273471f088e059214884e4a0fc54fd333d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2ef89b28fd9e9fd45dbc35030e22c273471f088e059214884e4a0fc54fd333d1->enter($__internal_2ef89b28fd9e9fd45dbc35030e22c273471f088e059214884e4a0fc54fd333d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SubAdminBundle:Users:SAdminAllMembers.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2ef89b28fd9e9fd45dbc35030e22c273471f088e059214884e4a0fc54fd333d1->leave($__internal_2ef89b28fd9e9fd45dbc35030e22c273471f088e059214884e4a0fc54fd333d1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_140aaf10d6dc2c4272dad69c7de7b9e6befcb53dfdaad62c8e8a7c3fa7d3d303 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_140aaf10d6dc2c4272dad69c7de7b9e6befcb53dfdaad62c8e8a7c3fa7d3d303->enter($__internal_140aaf10d6dc2c4272dad69c7de7b9e6befcb53dfdaad62c8e8a7c3fa7d3d303_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        // line 5
        echo "    <script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>
    ";
        // line 115
        echo "    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>

    <h4>All Members</h4>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Picture</th>
            <th>Userid</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 188
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["SAdminAllMembers"] ?? $this->getContext($context, "SAdminAllMembers")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 189
            echo "            ";
            if (($this->getAttribute($context["item"], "block", array()) != 2)) {
                // line 190
                echo "                <tr class=\"odd gradeX\" style=\"text-align: center;\">
                    ";
                // line 191
                if (($this->getAttribute($context["item"], "privacy", array()) == 1)) {
                    // line 192
                    echo "                        <td> &nbsp; <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/assets/icon.png"), "html", null, true);
                    echo "\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    ";
                } else {
                    // line 194
                    echo "                        <td> &nbsp; <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($this->getAttribute($context["item"], "upic", array())), "html", null, true);
                    echo "\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    ";
                }
                // line 196
                echo "                    <td style=\"vertical-align: middle;\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "userid", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 197
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uname", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 198
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uphone", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 199
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "umartialstatus", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 200
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uage", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 201
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "country", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 202
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "state", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 203
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "city", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 204
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "religion", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 205
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "caste", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 206
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "startdate", array()), "html", null, true);
                echo "</td>
                    ";
                // line 207
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->controller("AdminBundle:Sidebar:AdminUserPackagePartialView", array("id" => $this->getAttribute(                // line 208
$context["item"], "id", array()))));
                // line 209
                echo "
                    <td class=\"col-md-2\" style=\"text-align: center;\">
                        ";
                // line 212
                echo "                        <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_users_profile_for_others", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"View Profile\" class=\"btn btn-primary\"> <i class=\"entypo-eye\"></i></a>
                        <a href=\"";
                // line 213
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_users_interest", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Send Interest\" class=\"btn btn-info\"><i class=\"entypo-heart\"></i></a>
                    </td>
                </tr>
            ";
            }
            // line 217
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 218
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>User ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_140aaf10d6dc2c4272dad69c7de7b9e6befcb53dfdaad62c8e8a7c3fa7d3d303->leave($__internal_140aaf10d6dc2c4272dad69c7de7b9e6befcb53dfdaad62c8e8a7c3fa7d3d303_prof);

    }

    public function getTemplateName()
    {
        return "SubAdminBundle:Users:SAdminAllMembers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  322 => 218,  316 => 217,  309 => 213,  304 => 212,  300 => 209,  298 => 208,  297 => 207,  293 => 206,  289 => 205,  285 => 204,  281 => 203,  277 => 202,  273 => 201,  269 => 200,  265 => 199,  261 => 198,  257 => 197,  252 => 196,  246 => 194,  240 => 192,  238 => 191,  235 => 190,  232 => 189,  228 => 188,  153 => 115,  42 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::subadmin.html.twig' %}

{% block body %}
    {#filtration scripts#}
    <script>
        function myFunction() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"name\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[2];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction1() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"age\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[5];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction2() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"userid\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[1];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction3() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"country\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[6];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction4() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"religion\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[9];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }

        function myFunction5() {
            var input, filter, table, tr, td, i;
            input = document.getElementById(\"package\");
            filter = input.value.toUpperCase();
            table = document.getElementById(\"table-1\");
            tr = table.getElementsByTagName(\"tr\");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName(\"td\")[13];
                if (td) {
                    if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = \"\";
                    } else {
                        tr[i].style.display = \"none\";
                    }
                }
            }
        }
    </script>
    {#filtration scripts#}
    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>

    <h4>All Members</h4>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Picture</th>
            <th>Userid</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        {% for item in SAdminAllMembers %}
            {% if item.block != 2 %}
                <tr class=\"odd gradeX\" style=\"text-align: center;\">
                    {% if item.privacy == 1 %}
                        <td> &nbsp; <img src=\"{{ asset('bundles/assets/icon.png') }}\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    {% else %}
                        <td> &nbsp; <img src=\"{{ asset(item.upic) }}\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    {% endif %}
                    <td style=\"vertical-align: middle;\">{{ item.userid }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uname }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uphone }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.umartialstatus }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uage }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.country.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.state.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.city.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.religion.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.caste.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.startdate }}</td>
                    {{ render(controller(
                        'AdminBundle:Sidebar:AdminUserPackagePartialView',{'id':item.id}
                    )) }}
                    <td class=\"col-md-2\" style=\"text-align: center;\">
                        {#<a href=\"{{ path('sub_admins_users_update',{id:item.id}) }}\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>#}
                        <a href=\"{{ path('sub_admins_users_profile_for_others',{id:item.id}) }}\" title=\"View Profile\" class=\"btn btn-primary\"> <i class=\"entypo-eye\"></i></a>
                        <a href=\"{{ path('sub_admins_users_interest',{id:item.id}) }}\" title=\"Send Interest\" class=\"btn btn-info\"><i class=\"entypo-heart\"></i></a>
                    </td>
                </tr>
            {% endif %}
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>User ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "SubAdminBundle:Users:SAdminAllMembers.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\SubadminBundle/Resources/views/Users/SAdminAllMembers.html.twig");
    }
}
