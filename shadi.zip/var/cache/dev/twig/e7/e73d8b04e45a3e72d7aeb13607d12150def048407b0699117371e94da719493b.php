<?php

/* SubAdminBundle:Interest:Interest.html.twig */
class __TwigTemplate_26ade81ff011729ead0d787e8507de76ae91ddbfb7863f0d3fa12e8e0ac07e7b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::subadmin.html.twig", "SubAdminBundle:Interest:Interest.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::subadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c15d95aa4e358b2206b234280ecbaa5dfac165a2357669e4e873bc08b7b8fcf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c15d95aa4e358b2206b234280ecbaa5dfac165a2357669e4e873bc08b7b8fcf->enter($__internal_7c15d95aa4e358b2206b234280ecbaa5dfac165a2357669e4e873bc08b7b8fcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SubAdminBundle:Interest:Interest.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7c15d95aa4e358b2206b234280ecbaa5dfac165a2357669e4e873bc08b7b8fcf->leave($__internal_7c15d95aa4e358b2206b234280ecbaa5dfac165a2357669e4e873bc08b7b8fcf_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_40f547603ef83128ca6baa636d2b45b70beabec78bb4d285b7f78255b24642b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40f547603ef83128ca6baa636d2b45b70beabec78bb4d285b7f78255b24642b0->enter($__internal_40f547603ef83128ca6baa636d2b45b70beabec78bb4d285b7f78255b24642b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<h2>Send Interest</h2> <br/>
<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"panel panel-primary\" data-collapsed=\"0\">
            <div class=\"panel-heading\">
                <div class=\"panel-title\">
                    Send Interest
                </div>
                <div class=\"panel-options\"> <a href=\"#\" data-rel=\"collapse\"><i
                                class=\"entypo-down-open\"></i></a> <a href=\"#\" data-rel=\"reload\"><i
                                class=\"entypo-arrows-ccw\"></i></a> <a href=\"#\" data-rel=\"close\"><i
                                class=\"entypo-cancel\"></i></a></div>
            </div>
            <div class=\"panel-body\">
                <form action=\"\" method=\"post\" role=\"form\" class=\"form-horizontal form-groups-bordered\">
                    <div class=\"form-group\">
                        <label class=\"col-sm-3 control-label\">Send By</label>
                        <div class=\"col-sm-5\">
                            <select name=\"receiver\" required class=\"form-control\">
                                <option selected>Select One</option>
                                ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Users"] ?? $this->getContext($context, "Users")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 26
            echo "                                    ";
            if (($this->getAttribute($context["item"], "block", array()) != 2)) {
                // line 27
                echo "                                        <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "Uname", array()), "html", null, true);
                echo "</option>
                                    ";
            }
            // line 29
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "                            </select>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-offset-3 col-sm-5\">
                            <button type=\"submit\" class=\"btn btn-default\">Send Interest</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <br><br><br><br><br>
    <br><br><br><br><br>

";
        
        $__internal_40f547603ef83128ca6baa636d2b45b70beabec78bb4d285b7f78255b24642b0->leave($__internal_40f547603ef83128ca6baa636d2b45b70beabec78bb4d285b7f78255b24642b0_prof);

    }

    public function getTemplateName()
    {
        return "SubAdminBundle:Interest:Interest.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 30,  78 => 29,  70 => 27,  67 => 26,  63 => 25,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::subadmin.html.twig' %}

{% block body %}

<h2>Send Interest</h2> <br/>
<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"panel panel-primary\" data-collapsed=\"0\">
            <div class=\"panel-heading\">
                <div class=\"panel-title\">
                    Send Interest
                </div>
                <div class=\"panel-options\"> <a href=\"#\" data-rel=\"collapse\"><i
                                class=\"entypo-down-open\"></i></a> <a href=\"#\" data-rel=\"reload\"><i
                                class=\"entypo-arrows-ccw\"></i></a> <a href=\"#\" data-rel=\"close\"><i
                                class=\"entypo-cancel\"></i></a></div>
            </div>
            <div class=\"panel-body\">
                <form action=\"\" method=\"post\" role=\"form\" class=\"form-horizontal form-groups-bordered\">
                    <div class=\"form-group\">
                        <label class=\"col-sm-3 control-label\">Send By</label>
                        <div class=\"col-sm-5\">
                            <select name=\"receiver\" required class=\"form-control\">
                                <option selected>Select One</option>
                                {% for item in Users %}
                                    {% if item.block != 2 %}
                                        <option value=\"{{ item.id }}\">{{ item.Uname }}</option>
                                    {% endif %}
                                {% endfor %}
                            </select>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-offset-3 col-sm-5\">
                            <button type=\"submit\" class=\"btn btn-default\">Send Interest</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <br><br><br><br><br>
    <br><br><br><br><br>

{% endblock %}", "SubAdminBundle:Interest:Interest.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\SubadminBundle/Resources/views/Interest/Interest.html.twig");
    }
}
