<?php

/* AdminBundle:Admin/Caste:caste.html.twig */
class __TwigTemplate_2eb6a891eac896a9fa528de7b7e4f82f4d8a78b147ea23b0ad79b1b7eed31e94 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Admin/Caste:caste.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fdcaeba42c0b5d353a207b90f933c4f7f55fea5de17ebf02b6f5aecf4918c12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9fdcaeba42c0b5d353a207b90f933c4f7f55fea5de17ebf02b6f5aecf4918c12->enter($__internal_9fdcaeba42c0b5d353a207b90f933c4f7f55fea5de17ebf02b6f5aecf4918c12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Caste:caste.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9fdcaeba42c0b5d353a207b90f933c4f7f55fea5de17ebf02b6f5aecf4918c12->leave($__internal_9fdcaeba42c0b5d353a207b90f933c4f7f55fea5de17ebf02b6f5aecf4918c12_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_d1fbde57babe195a38a9a863c5cdeb74e1ec107d86e4b9cccab4b47052c6c2ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1fbde57babe195a38a9a863c5cdeb74e1ec107d86e4b9cccab4b47052c6c2ca->enter($__internal_d1fbde57babe195a38a9a863c5cdeb74e1ec107d86e4b9cccab4b47052c6c2ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4 style=\"padding: 10px 0px;\">Caste</h4> <span><a href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_caste_insert");
        echo "\" class=\"btn btn-info\">Add Caste</a></span>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Religion</th>
            <th>Caste</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["Caste"] ?? $this->getContext($context, "Caste")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 43
            echo "            <tr class=\"odd gradeX\">
                <td> &nbsp; ";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "religion", array()), "name", array()), "html", null, true);
            echo "</td>
                <td> &nbsp; ";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "name", array()), "html", null, true);
            echo "</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"";
            // line 47
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_caste_update", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 51
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>Religion</th>
            <th>Caste</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_d1fbde57babe195a38a9a863c5cdeb74e1ec107d86e4b9cccab4b47052c6c2ca->leave($__internal_d1fbde57babe195a38a9a863c5cdeb74e1ec107d86e4b9cccab4b47052c6c2ca_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Caste:caste.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 51,  99 => 47,  94 => 45,  90 => 44,  87 => 43,  83 => 42,  69 => 31,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::admin.html.twig' %}

{% block body %}
    <style>
        /*.dt-buttons{
            display: none!important;
        }*/
    </style>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <h4 style=\"padding: 10px 0px;\">Caste</h4> <span><a href=\"{{ path('admin_caste_insert') }}\" class=\"btn btn-info\">Add Caste</a></span>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>Religion</th>
            <th>Caste</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>

        {% for item in Caste %}
            <tr class=\"odd gradeX\">
                <td> &nbsp; {{ item.religion.name }}</td>
                <td> &nbsp; {{ item.name }}</td>
                <td class=\"col-md-2\" style=\"text-align: center;\">
                    <a href=\"{{ path('admin_caste_update',{id:item.id}) }}\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>Religion</th>
            <th>Caste</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "AdminBundle:Admin/Caste:caste.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Caste/caste.html.twig");
    }
}
