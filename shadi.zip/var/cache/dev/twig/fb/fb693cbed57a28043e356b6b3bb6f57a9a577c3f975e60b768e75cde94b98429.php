<?php

/* SubAdminBundle:Users:OtherSAdminMembers.html.twig */
class __TwigTemplate_38a333c0e5c5403ff8838bd649c44f14fcd2c66bf08c226f8d34b8604565d20b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::subadmin.html.twig", "SubAdminBundle:Users:OtherSAdminMembers.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::subadmin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_026e2942ea329abf15101ac7480a322f6db80699607b8a3bd76d4a1a7f764ca8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_026e2942ea329abf15101ac7480a322f6db80699607b8a3bd76d4a1a7f764ca8->enter($__internal_026e2942ea329abf15101ac7480a322f6db80699607b8a3bd76d4a1a7f764ca8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SubAdminBundle:Users:OtherSAdminMembers.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_026e2942ea329abf15101ac7480a322f6db80699607b8a3bd76d4a1a7f764ca8->leave($__internal_026e2942ea329abf15101ac7480a322f6db80699607b8a3bd76d4a1a7f764ca8_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6d1a38b65156e2500422c28829ddcf562ccbb7ab99e51ac99a76d2d1ab476b98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d1a38b65156e2500422c28829ddcf562ccbb7ab99e51ac99a76d2d1ab476b98->enter($__internal_6d1a38b65156e2500422c28829ddcf562ccbb7ab99e51ac99a76d2d1ab476b98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>

    <h4>Other Sub Admin Members</h4>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 78
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["SAdminAllMembers"] ?? $this->getContext($context, "SAdminAllMembers")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 79
            echo "            ";
            if (($this->getAttribute($this->getAttribute($context["item"], "subadmin", array()), "id", array()) == null)) {
                // line 80
                echo "                <tr class=\"odd gradeX\" style=\"text-align: center;\">
                    ";
                // line 81
                if (($this->getAttribute($context["item"], "privacy", array()) == 1)) {
                    // line 82
                    echo "                        <td> &nbsp; <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/assets/icon.png"), "html", null, true);
                    echo "\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    ";
                } else {
                    // line 84
                    echo "                        <td> &nbsp; <img src=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($this->getAttribute($context["item"], "upic", array())), "html", null, true);
                    echo "\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    ";
                }
                // line 86
                echo "                    <td style=\"vertical-align: middle;\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "userid", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 87
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uname", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 88
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uphone", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 89
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "umartialstatus", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 90
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "uage", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 91
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "country", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 92
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "state", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 93
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "city", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 94
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "religion", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 95
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["item"], "caste", array()), "name", array()), "html", null, true);
                echo "</td>
                    <td style=\"vertical-align: middle;\">";
                // line 96
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "startdate", array()), "html", null, true);
                echo "</td>
                    ";
                // line 97
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->controller("AdminBundle:Sidebar:AdminUserPackagePartialView", array("id" => $this->getAttribute(                // line 98
$context["item"], "id", array()))));
                // line 99
                echo "
                    <td class=\"col-md-3\" style=\"padding: 20px 0px; text-align: center;\">
                        ";
                // line 102
                echo "                        <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_users_profile_for_others", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"View Profile\" class=\"btn btn-primary\"> <i class=\"entypo-eye\"></i></a>
                        <a href=\"";
                // line 103
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sub_admins_users_interest", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
                echo "\" title=\"Send Interest\" class=\"btn btn-info\"><i class=\"entypo-heart\"></i></a>
                    </td>
                </tr>
            ";
            }
            // line 107
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 108
        echo "        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


";
        
        $__internal_6d1a38b65156e2500422c28829ddcf562ccbb7ab99e51ac99a76d2d1ab476b98->leave($__internal_6d1a38b65156e2500422c28829ddcf562ccbb7ab99e51ac99a76d2d1ab476b98_prof);

    }

    public function getTemplateName()
    {
        return "SubAdminBundle:Users:OtherSAdminMembers.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 108,  204 => 107,  197 => 103,  192 => 102,  188 => 99,  186 => 98,  185 => 97,  181 => 96,  177 => 95,  173 => 94,  169 => 93,  165 => 92,  161 => 91,  157 => 90,  153 => 89,  149 => 88,  145 => 87,  140 => 86,  134 => 84,  128 => 82,  126 => 81,  123 => 80,  120 => 79,  116 => 78,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::subadmin.html.twig' %}

{% block body %}

    <div class=\"col-md-12\" style=\"padding-bottom: 50px;\">
        <div class=\"col-md-12\">
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Name</label>
                <input type=\"text\" id=\"name\" class=\"form-control\" onkeyup=\"myFunction()\" placeholder=\"Name\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Age</label>
                <input type=\"text\" id=\"age\" class=\"form-control\" onkeyup=\"myFunction1()\" placeholder=\"Age\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search User Id</label>
                <input type=\"text\" id=\"userid\" class=\"form-control\" onkeyup=\"myFunction2()\" placeholder=\"User ID\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Country</label>
                <input type=\"text\" id=\"country\" class=\"form-control\" onkeyup=\"myFunction3()\" placeholder=\"Country\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Religion</label>
                <input type=\"text\" id=\"religion\" class=\"form-control\" onkeyup=\"myFunction4()\" placeholder=\"Religion\">
            </div>
            <div class=\"col-md-2\">
                <label for=\"name\" class=\"label label-primary\">Search Package</label>
                <input type=\"text\" id=\"package\" class=\"form-control\" onkeyup=\"myFunction5()\" placeholder=\"Package\">
            </div>
        </div>
    </div>

    <script type=\"text/javascript\">
        jQuery(document).ready(function (\$) {
            var \$table1 = jQuery('#table-1');
// Initialize DataTable
            \$table1.DataTable({
                \"aLengthMenu\": [[10, 25, 50, -1], [10, 25, 50, \"All\"]],
                \"bStateSave\": true,
                dom: 'lBfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            });
// Initalize Select Dropdown after DataTables is created
            \$table1.closest('.dataTables_wrapper').find('select').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>

    <h4>Other Sub Admin Members</h4>
    <table class=\"table table-bordered datatable\" id=\"table-1\">
        <thead>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        {% for item in SAdminAllMembers %}
            {% if item.subadmin.id == null %}
                <tr class=\"odd gradeX\" style=\"text-align: center;\">
                    {% if item.privacy == 1 %}
                        <td> &nbsp; <img src=\"{{ asset('bundles/assets/icon.png') }}\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    {% else %}
                        <td> &nbsp; <img src=\"{{ asset(item.upic) }}\" style=\"width: 60px; height: 60px;\" alt=\"\"> </td>
                    {% endif %}
                    <td style=\"vertical-align: middle;\">{{ item.userid }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uname }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uphone }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.umartialstatus }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.uage }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.country.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.state.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.city.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.religion.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.caste.name }}</td>
                    <td style=\"vertical-align: middle;\">{{ item.startdate }}</td>
                    {{ render(controller(
                        'AdminBundle:Sidebar:AdminUserPackagePartialView',{'id':item.id}
                    )) }}
                    <td class=\"col-md-3\" style=\"padding: 20px 0px; text-align: center;\">
                        {#<a href=\"{{ path('sub_admins_users_update',{id:item.id}) }}\" class=\"btn btn-default btn-sm btn-icon icon-left\"> <i class=\"entypo-pencil\"></i>Edit</a>#}
                        <a href=\"{{ path('sub_admins_users_profile_for_others',{id:item.id}) }}\" title=\"View Profile\" class=\"btn btn-primary\"> <i class=\"entypo-eye\"></i></a>
                        <a href=\"{{ path('sub_admins_users_interest',{id:item.id}) }}\" title=\"Send Interest\" class=\"btn btn-info\"><i class=\"entypo-heart\"></i></a>
                    </td>
                </tr>
            {% endif %}
        {% endfor %}
        </tbody>
        <tfoot>
        <tr>
            <th>User Image</th>
            <th>Member Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Martial Status</th>
            <th>Age</th>
            <th>Country</th>
            <th>State</th>
            <th>City</th>
            <th>Religion</th>
            <th>Caste</th>
            <th>Member Since</th>
            <th>Package</th>
            <th>Expire Date</th>
            <th>Action</th>
        </tr>
        </tfoot>
    </table>


{% endblock %}", "SubAdminBundle:Users:OtherSAdminMembers.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\SubadminBundle/Resources/views/Users/OtherSAdminMembers.html.twig");
    }
}
