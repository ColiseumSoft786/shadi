<?php

/* AdminBundle:Admin/Subadmin:addsubadmin.html.twig */
class __TwigTemplate_10abb812818f85396a5de782bdb7248832590f796060b18078b28ecaffa96ed2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::admin.html.twig", "AdminBundle:Admin/Subadmin:addsubadmin.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_935f5a5c57c46a2fcf56829857c72bb01f2568999ed10c930e8d9352be5e82d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_935f5a5c57c46a2fcf56829857c72bb01f2568999ed10c930e8d9352be5e82d3->enter($__internal_935f5a5c57c46a2fcf56829857c72bb01f2568999ed10c930e8d9352be5e82d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AdminBundle:Admin/Subadmin:addsubadmin.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_935f5a5c57c46a2fcf56829857c72bb01f2568999ed10c930e8d9352be5e82d3->leave($__internal_935f5a5c57c46a2fcf56829857c72bb01f2568999ed10c930e8d9352be5e82d3_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ccecdd53b3350de8173cdf48d6ba0ef0482f30fbe40e6ba58fd0920d53febf87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ccecdd53b3350de8173cdf48d6ba0ef0482f30fbe40e6ba58fd0920d53febf87->enter($__internal_ccecdd53b3350de8173cdf48d6ba0ef0482f30fbe40e6ba58fd0920d53febf87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<h2>Add Sub Admin</h2> <br/>
<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"panel panel-primary\" data-collapsed=\"0\">
            <div class=\"panel-heading\">
                <div class=\"panel-title\">
                    Insert Sub Admin
                </div>
                <div class=\"panel-options\"> <a href=\"#\" data-rel=\"collapse\"><i
                                class=\"entypo-down-open\"></i></a> <a href=\"#\" data-rel=\"reload\"><i
                                class=\"entypo-arrows-ccw\"></i></a> <a href=\"#\" data-rel=\"close\"><i
                                class=\"entypo-cancel\"></i></a></div>
            </div>
            <div class=\"panel-body\">
                <form action=\"\" method=\"post\" role=\"form\" class=\"form-horizontal form-groups-bordered\">
                    <div class=\"form-group\">
                        <label for=\"field-1\" class=\"col-sm-3 control-label\">Name</label>
                        <div class=\"col-sm-5\">
                            <input type=\"text\" name=\"name\" required class=\"form-control\" id=\"field-1\"
                                                     placeholder=\"Placeholder(Name)\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"field-1\" class=\"col-sm-3 control-label\">Phone</label>
                        <div class=\"col-sm-5\">
                            <input type=\"tel\" required name=\"phone\" class=\"form-control\" id=\"field-1\"
                                                     placeholder=\"Placeholder(Phone)\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"field-1\" class=\"col-sm-3 control-label\">Password</label>
                        <div class=\"col-sm-5\">
                            <input type=\"password\" required name=\"password\" class=\"form-control\" id=\"field-1\"
                                                     placeholder=\"Placeholder(Password)\">
                        </div>
                    </div>
                    ";
        // line 45
        echo "                    ";
        // line 54
        echo "                    <div class=\"form-group\">
                        <div class=\"col-sm-offset-3 col-sm-5\">
                            <button type=\"submit\" class=\"btn btn-default\">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <br><br><br><br><br>
    <br><br><br><br><br>

";
        
        $__internal_ccecdd53b3350de8173cdf48d6ba0ef0482f30fbe40e6ba58fd0920d53febf87->leave($__internal_ccecdd53b3350de8173cdf48d6ba0ef0482f30fbe40e6ba58fd0920d53febf87_prof);

    }

    public function getTemplateName()
    {
        return "AdminBundle:Admin/Subadmin:addsubadmin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 54,  79 => 45,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends'::admin.html.twig' %}

{% block body %}

<h2>Add Sub Admin</h2> <br/>
<div class=\"row\">
    <div class=\"col-md-12\">
        <div class=\"panel panel-primary\" data-collapsed=\"0\">
            <div class=\"panel-heading\">
                <div class=\"panel-title\">
                    Insert Sub Admin
                </div>
                <div class=\"panel-options\"> <a href=\"#\" data-rel=\"collapse\"><i
                                class=\"entypo-down-open\"></i></a> <a href=\"#\" data-rel=\"reload\"><i
                                class=\"entypo-arrows-ccw\"></i></a> <a href=\"#\" data-rel=\"close\"><i
                                class=\"entypo-cancel\"></i></a></div>
            </div>
            <div class=\"panel-body\">
                <form action=\"\" method=\"post\" role=\"form\" class=\"form-horizontal form-groups-bordered\">
                    <div class=\"form-group\">
                        <label for=\"field-1\" class=\"col-sm-3 control-label\">Name</label>
                        <div class=\"col-sm-5\">
                            <input type=\"text\" name=\"name\" required class=\"form-control\" id=\"field-1\"
                                                     placeholder=\"Placeholder(Name)\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"field-1\" class=\"col-sm-3 control-label\">Phone</label>
                        <div class=\"col-sm-5\">
                            <input type=\"tel\" required name=\"phone\" class=\"form-control\" id=\"field-1\"
                                                     placeholder=\"Placeholder(Phone)\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label for=\"field-1\" class=\"col-sm-3 control-label\">Password</label>
                        <div class=\"col-sm-5\">
                            <input type=\"password\" required name=\"password\" class=\"form-control\" id=\"field-1\"
                                                     placeholder=\"Placeholder(Password)\">
                        </div>
                    </div>
                    {#<div class=\"form-group\"><label for=\"field-3\" class=\"col-sm-3 control-label\">Password</label>
                        <div class=\"col-sm-5\"><input type=\"password\" class=\"form-control\" id=\"field-3\"
                                                     placeholder=\"Placeholder (Password)\"></div>
                    </div>#}
                    {#<div class=\"form-group\"><label class=\"col-sm-3 control-label\">Select List</label>
                        <div class=\"col-sm-5\"><select class=\"form-control\">
                                <option>Option 1</option>
                                <option>Option 2</option>
                                <option>Option 3</option>
                                <option>Option 4</option>
                                <option>Option 5</option>
                            </select></div>
                    </div>#}
                    <div class=\"form-group\">
                        <div class=\"col-sm-offset-3 col-sm-5\">
                            <button type=\"submit\" class=\"btn btn-default\">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <br><br><br><br><br>
    <br><br><br><br><br>

{% endblock %}", "AdminBundle:Admin/Subadmin:addsubadmin.html.twig", "C:\\xampp72\\htdocs\\symfony3\\shadi\\src\\App\\AdminBundle/Resources/views/Admin/Subadmin/addsubadmin.html.twig");
    }
}
